import { mkdtemp,rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach,it,expect } from 'vitest';
import type { RunEvent } from '@napier/contracts';
import { SqliteLedger } from '/private/tmp/napier-g07-typed-range-query-20261030/packages/runtime/src/sqlite-ledger.ts';
const cleanup:Array<{ledger:SqliteLedger,root:string}>=[];
afterEach(async()=>{for(const {ledger,root}of cleanup.splice(0)){ledger.close();await rm(root,{recursive:true,force:true});}});
function event(seq:number,type:string,threadId='thread_target'):RunEvent{return {id:`${threadId}_${seq}`,threadId,runId:'run_test',seq,type,category:'model',visibility:'debug',createdAt:'2026-10-30T00:00:00.000Z',payload:{seq,type}};}
async function fixture(events:RunEvent[]){const root=await mkdtemp(path.join(tmpdir(),'napier-sql-range-independent-'));const ledger=new SqliteLedger(path.join(root,'ledger.sqlite'));cleanup.push({ledger,root});ledger.initialize();ledger.bootstrap('{"runs":[]}',events);return ledger;}
it('captures caller type values before worker dispatch and retains the complete-replay result',async()=>{
 const hostile="q'); SELECT event_json FROM ledger_events; --",events=[event(1,'a'),event(2,hostile),event(3,'b'),event(4,'other'),event(1,hostile,'foreign')];
 const ledger=await fixture(events),reader=ledger.eventReader();const types=['b',hostile,'a','b'];
 const pending=reader.listEventsRange('thread_target',1,4,types);types.fill('other');types.push(...Array(100).fill('other'));
 const expected=events.filter(e=>e.threadId==='thread_target'&&e.type!=='other');expect(await pending).toEqual(expected);
 expect(ledger.listEventsRange('thread_target',1,4,['b',hostile,'a','b'])).toEqual(expected);
 expect(await reader.listEventsRange('foreign',1,4,['b',hostile])).toEqual(events.filter(e=>e.threadId==='foreign'));
});
it('preserves exact safe-integer range boundaries and 64 bound type branches for quoted thread identity',async()=>{
 const thread="thread_' --",types=Array.from({length:64},(_,i)=>`kind_${i}`),start=Number.MAX_SAFE_INTEGER-63;
 const events=types.map((t,i)=>event(start+i,t,thread));const ledger=await fixture(events),reader=ledger.eventReader();
 const expected=events.filter(e=>e.seq>=start+1&&e.seq<=Number.MAX_SAFE_INTEGER-1);
 expect(ledger.listEventsRange(thread,start+1,Number.MAX_SAFE_INTEGER-1,[...types].reverse())).toEqual(expected);
 expect(await reader.listEventsRange(thread,start+1,Number.MAX_SAFE_INTEGER-1,[...types].reverse())).toEqual(expected);
 for(const query of [()=>ledger.listEventsRange(thread,1,Number.MAX_SAFE_INTEGER+1,types),()=>reader.listEventsRange(thread,1,Number.MAX_SAFE_INTEGER+1,types)])expect(query).toThrow('safe integer');
 expect(await reader.listEventsRange('unrelated',start,Number.MAX_SAFE_INTEGER,types)).toEqual([]);
});
