import { compileTypedEventRangeQuery } from "./sqlite-event-range-query.js";
import { normalizeEventQueryTypes, validateEventQueryId, validateEventQuerySeq, } from "./run-event-query-port.js";
const TOOL_TERMINAL_TYPES = [
    "tool.completed",
    "tool.failed",
    "tool.blocked",
];
export class SqliteLedgerQuery {
    database;
    constructor(database) {
        this.database = database;
    }
    listRunEvents(runId, afterSeq = 0, types) {
        const normalizedTypes = normalizeEventQueryTypes(types);
        if (normalizedTypes?.length === 0)
            return [];
        const parameters = [
            validateEventQueryId(runId, "Run ID"),
            validateEventQuerySeq(afterSeq, "afterSeq"),
        ];
        const clauses = ["run_id = ?", "seq > ?"];
        appendTypePredicate(clauses, parameters, normalizedTypes);
        return this.all(clauses, parameters);
    }
    listEventsRange(threadId, fromSeq, toSeq, types) {
        validateEventQueryId(threadId, "Thread ID");
        validateEventQuerySeq(fromSeq, "fromSeq", 1);
        validateEventQuerySeq(toSeq, "toSeq", 1);
        if (fromSeq > toSeq) {
            throw new Error("Event range requires fromSeq <= toSeq");
        }
        const normalizedTypes = normalizeEventQueryTypes(types);
        if (normalizedTypes?.length === 0)
            return [];
        const clauses = ["thread_id = ?", "seq BETWEEN ? AND ?"];
        const parameters = [threadId, fromSeq, toSeq];
        const compound = compileTypedEventRangeQuery(threadId, fromSeq, toSeq, normalizedTypes);
        if (compound) {
            const rows = this.database.prepare(compound.sql).all(...compound.parameters);
            return rows.map(parseEvent);
        }
        appendTypePredicate(clauses, parameters, normalizedTypes);
        return this.all(clauses, parameters);
    }
    findLatestEvent(query) {
        const built = buildScope(query, true);
        if (built.empty)
            return undefined;
        return this.first(built.clauses, built.parameters);
    }
    findToolTerminal(callId, scope = {}) {
        const built = buildScope(scope, false);
        built.clauses.unshift("json_extract(event_json, '$.payload.callId') = ?");
        built.parameters.unshift(validateEventQueryId(callId, "Tool call ID"));
        appendTypePredicate(built.clauses, built.parameters, TOOL_TERMINAL_TYPES);
        return this.first(built.clauses, built.parameters);
    }
    listEventsByCorrelationId(correlationId, scope = {}) {
        const built = buildScope(scope, false);
        if (built.empty)
            return [];
        built.clauses.unshift("json_extract(event_json, '$.payload.correlationId') = ?");
        built.parameters.unshift(validateEventQueryId(correlationId, "Correlation ID"));
        return this.all(built.clauses, built.parameters);
    }
    all(clauses, parameters) {
        const rows = this.database
            .prepare(`SELECT event_json FROM ledger_events
         WHERE ${clauses.join(" AND ")}
         ORDER BY seq ASC`)
            .all(...parameters);
        return rows.map(parseEvent);
    }
    first(clauses, parameters) {
        const row = this.database
            .prepare(`SELECT event_json FROM ledger_events
         WHERE ${clauses.join(" AND ")}
         ORDER BY seq DESC LIMIT 1`)
            .get(...parameters);
        return row ? parseEvent(row) : undefined;
    }
}
function buildScope(scope, requireOwner) {
    const clauses = [];
    const parameters = [];
    if (scope.threadId !== undefined) {
        clauses.push("thread_id = ?");
        parameters.push(validateEventQueryId(scope.threadId, "Thread ID"));
    }
    if (scope.runId !== undefined) {
        clauses.push("run_id = ?");
        parameters.push(validateEventQueryId(scope.runId, "Run ID"));
    }
    if (requireOwner && clauses.length === 0) {
        throw new Error("Latest event query requires a Thread ID or Run ID");
    }
    if (scope.afterSeq !== undefined) {
        clauses.push("seq > ?");
        parameters.push(validateEventQuerySeq(scope.afterSeq, "afterSeq"));
    }
    if (scope.atOrBeforeSeq !== undefined) {
        clauses.push("seq <= ?");
        parameters.push(validateEventQuerySeq(scope.atOrBeforeSeq, "atOrBeforeSeq", 1));
    }
    const types = normalizeEventQueryTypes(scope.types);
    appendTypePredicate(clauses, parameters, types);
    return { clauses, parameters, empty: types?.length === 0 };
}
function appendTypePredicate(clauses, parameters, types) {
    if (!types?.length)
        return;
    clauses.push(`event_type IN (${types.map(() => "?").join(", ")})`);
    parameters.push(...types);
}
function parseEvent(row) {
    return JSON.parse(row.event_json);
}
