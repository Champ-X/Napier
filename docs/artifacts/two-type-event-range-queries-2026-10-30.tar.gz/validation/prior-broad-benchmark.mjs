import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { SqliteLedger } from '/private/tmp/napier-g07-typed-range-query-20261030/packages/runtime/dist/sqlite-ledger.js';
import { SqliteLedgerQuery } from '/private/tmp/napier-g07-typed-range-query-20261030/packages/runtime/dist/sqlite-ledger-query.js';
import { compileTypedEventRangeQuery } from '/private/tmp/napier-g07-typed-range-query-20261030/packages/runtime/dist/sqlite-event-range-query.js';

const out='/tmp/napier-g07-typed-range-benchmark-20261030';mkdirSync(out,{recursive:true});
const protocol={scales:[10000,100000],cases:[{name:'sparse2',types:2,sparse:true},{name:'dense2',types:2},{name:'dense8',types:8},{name:'dense64',types:64}],order:['baseline','candidate','candidate','baseline'],samplesPerRound:3,warmupPerVariant:1,
  retentionRule:'Exact output equality and no more than 20 percent median wall regression in any dense workload; otherwise revise or reject broad activation. Exploratory single-machine query comparison; no production or statistical quality claim.'};
writeFileSync(out+'/protocol.json',JSON.stringify(protocol,null,2)+'\n');
const results=[];
for(const scale of protocol.scales) for(const c of protocol.cases){
 const file=`${out}/${c.name}-${scale}.sqlite`;if(existsSync(file))throw new Error('Refuse to overwrite previous benchmark');
 const types=Array.from({length:c.types},(_,i)=>`model.type_${i}`);
 const seed=new SqliteLedger(file);seed.initialize();
 const count=scale+(c.sparse?2:0);
 const events=Array.from({length:count},(_,i)=>({id:`event_${i+1}`,threadId:'thread_target',runId:'run_target',seq:i+1,type:c.sparse&&i>=2?'model.noise':types[i%types.length],category:'model',visibility:'debug',createdAt:'2026-10-30T00:00:00.000Z',payload:{text:'representative event payload '+String(i).padStart(8,'0')}}));
 seed.bootstrap('{"runs":[]}',events);seed.close();
 const db=new DatabaseSync(file,{readOnly:true});const query=new SqliteLedgerQuery(db);
 const baselineSql=`SELECT event_json FROM ledger_events WHERE thread_id = ? AND seq BETWEEN ? AND ? AND event_type IN (${types.map(()=>'?').join(', ')}) ORDER BY seq ASC`;
 const args=['thread_target',1,Number.MAX_SAFE_INTEGER,...types];const compiled=compileTypedEventRangeQuery('thread_target',1,Number.MAX_SAFE_INTEGER,types);
 const invoke={baseline:()=>db.prepare(baselineSql).all(...args).map(r=>JSON.parse(r.event_json)),candidate:()=>query.listEventsRange('thread_target',1,Number.MAX_SAFE_INTEGER,types)};
 const plans={baseline:db.prepare('EXPLAIN QUERY PLAN '+baselineSql).all(...args),candidate:db.prepare('EXPLAIN QUERY PLAN '+compiled.sql).all(...compiled.parameters)};
 const hash=rows=>createHash('sha256').update(JSON.stringify(rows)).digest('hex');let expected;
 for(const variant of ['baseline','candidate']){const rows=invoke[variant]();const digest=hash(rows);expected??=digest;if(digest!==expected)throw new Error('Warmup mismatch');}
 const samples=[];
 for(let round=0;round<protocol.order.length;round++){
  const variant=protocol.order[round];
  for(let i=0;i<protocol.samplesPerRound;i++){
   const cpu=process.cpuUsage(),start=performance.now();const rows=invoke[variant]();const wallMs=performance.now()-start,used=process.cpuUsage(cpu);const digest=hash(rows);
   if(digest!==expected)throw new Error('Measured mismatch');
   samples.push({variant,round,sample:i,wallMs,cpuMs:(used.user+used.system)/1000,rows:rows.length,outputSha256:digest,rss:process.memoryUsage().rss});
  }
 }
 db.close();
 const median=a=>{a.sort((x,y)=>x-y);return(a[a.length/2-1]+a[a.length/2])/2};
 const summary=Object.fromEntries(['baseline','candidate'].map(v=>[v,{wallMs:median(samples.filter(s=>s.variant===v).map(s=>s.wallMs)),cpuMs:median(samples.filter(s=>s.variant===v).map(s=>s.cpuMs))}]));
 const ratio=summary.candidate.wallMs/summary.baseline.wallMs;
 results.push({case:c.name,scale,types:c.types,sparse:!!c.sparse,plans,samples,summary,wallRatio:ratio,withinRetentionRule:!!c.sparse||ratio<=1.2});
 writeFileSync(out+'/results.json',JSON.stringify({protocol,node:process.version,results},null,2)+'\n');
 console.log(JSON.stringify({case:c.name,scale,summary,ratio,keep:!!c.sparse||ratio<=1.2}));
}
