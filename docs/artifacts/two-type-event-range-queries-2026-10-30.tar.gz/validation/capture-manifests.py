from pathlib import Path
import json,hashlib,sys
root=Path('/private/tmp/napier-g07-typed-range-query-20261030');out=Path('/tmp/napier-g07-typed-range-v2-validation-20261030');label=sys.argv[1]
def entries(paths):return [{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths) if p.is_file()]
source=entries([p for package in ['contracts','runtime']for folder in ['src','test']for p in (root/'packages'/package/folder).rglob('*') if p.suffix=='.ts'])
emitted=entries([p for package in ['contracts','runtime']for p in (root/'packages'/package/'dist').rglob('*') if p.is_file()])
(out/f'source-{label}.json').write_text(json.dumps(source,indent=2)+'\n');(out/f'emitted-{label}.json').write_text(json.dumps(emitted,indent=2)+'\n')
print(json.dumps({'label':label,'sourceFiles':len(source),'emittedFiles':len(emitted)}))
