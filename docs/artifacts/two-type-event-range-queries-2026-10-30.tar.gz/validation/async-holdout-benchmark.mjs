import { writeFileSync,readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { SqliteLedgerReadWorker as Baseline } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/dist/sqlite-ledger-read-worker.js';
import { SqliteLedgerReadWorker as Candidate } from '/private/tmp/napier-g07-typed-range-query-20261030/packages/runtime/dist/sqlite-ledger-read-worker.js';
const out='/tmp/napier-g07-typed-range-v2-validation-20261030';
const protocol={kind:'supplementary_actual_async_worker',scales:[25000,250000],case:'sparse2',order:['baseline','candidate','candidate','baseline'],samplesPerRound:3,samplesPerVariantPerScale:6,warmupsPerVariantPerScale:1,types:['model.type_0','model.type_1'],measurementBoundary:'Real listEventsRange promise wall time and whole-process CPU; one warmed worker per variant per scale, both read the same immutable database; no LocalStore initialization.',retentionRule:'Exact output digest equality. Supplemental sparse observations only; the original synchronous dense<=20%holdout gate is unchanged.'};
writeFileSync(out+'/async-protocol.json',JSON.stringify(protocol,null,2)+'\n');
const digest=x=>createHash('sha256').update(x).digest('hex');const results=[];
for(const scale of protocol.scales){
 const database=`/tmp/napier-g07-typed-range-holdout-v2-20261030/sparse2-${scale}.sqlite`;
 const sourceBefore=digest(readFileSync(database));const readers={baseline:new Baseline(database),candidate:new Candidate(database)};let expected;
 try{
  for(const variant of ['baseline','candidate']){const rows=await readers[variant].listEventsRange('thread_target',1,Number.MAX_SAFE_INTEGER,protocol.types);const hash=digest(JSON.stringify(rows));expected??=hash;if(hash!==expected||rows.length!==2)throw new Error('Warmup output mismatch');}
  const samples=[];
  for(let round=0;round<protocol.order.length;round++){
   const variant=protocol.order[round];
   for(let sample=0;sample<protocol.samplesPerRound;sample++){
    const cpu=process.cpuUsage(),start=performance.now();const rows=await readers[variant].listEventsRange('thread_target',1,Number.MAX_SAFE_INTEGER,protocol.types);const wallMs=performance.now()-start,used=process.cpuUsage(cpu);const hash=digest(JSON.stringify(rows));
    if(hash!==expected||rows.length!==2)throw new Error('Measured output mismatch');
    samples.push({variant,round,sample,wallMs,cpuMs:(used.user+used.system)/1000,rss:process.memoryUsage().rss,rows:rows.length,outputSha256:hash});
   }
  }
  const sourceAfter=digest(readFileSync(database));if(sourceBefore!==sourceAfter)throw new Error('Database changed');
  const median=a=>{a.sort((x,y)=>x-y);return(a[a.length/2-1]+a[a.length/2])/2};const summary=Object.fromEntries(['baseline','candidate'].map(variant=>[variant,{wallMs:median(samples.filter(s=>s.variant===variant).map(s=>s.wallMs)),cpuMs:median(samples.filter(s=>s.variant===variant).map(s=>s.cpuMs))}]));
  results.push({scale,database,databaseSha256:sourceBefore,databaseUnchanged:true,samples,summary,wallRatio:summary.candidate.wallMs/summary.baseline.wallMs});
  writeFileSync(out+'/async-results.json',JSON.stringify({protocol,node:process.version,results},null,2)+'\n');console.log(JSON.stringify({scale,summary,ratio:summary.candidate.wallMs/summary.baseline.wallMs}));
 }finally{readers.baseline.close();readers.candidate.close();}
}
