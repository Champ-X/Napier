import base from './source-alias-base.config.mts';
export default {...base,test:{...base.test,include:['packages/runtime/test/model-accounting-reconciliation-revision.test.ts'],reporters:['default','json'],outputFile:{json:'/tmp/napier-g03-duplicate-revision-evidence-20261030/regression-after.json'}}};
