import base from './source-alias-base.config.mts';
export default {...base, root: '/tmp/napier-g03-duplicate-revision-evidence-20261030', test:{...base.test, include:['review.test.ts'],reporters:['default','json'],outputFile:{json:'/tmp/napier-g03-duplicate-revision-evidence-20261030/review-before.json'}}};
