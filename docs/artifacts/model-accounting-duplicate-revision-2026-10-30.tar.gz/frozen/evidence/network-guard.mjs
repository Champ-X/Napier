import net from 'node:net';
import dgram from 'node:dgram';
import { appendFileSync } from 'node:fs';
import { threadId } from 'node:worker_threads';
import { syncBuiltinESMExports } from 'node:module';

const log = process.env.NAPIER_G03_NETWORK_AUDIT;
if (!log) throw new Error('NAPIER_G03_NETWORK_AUDIT is required');
function record(value) { appendFileSync(log, JSON.stringify({ pid: process.pid, threadId, ...value }) + '\n'); }
function local(host) { return host === undefined || host === 'localhost' || host === '::1' || host === '[::1]' || host === '0:0:0:0:0:0:0:1' || /^127\.(?:\d{1,3}\.){2}\d{1,3}$/u.test(String(host)); }
function assertLocal(kind, host, port, unix = false) {
  const allowed = unix || local(host);
  record({ event: 'connection', kind, destination: unix ? 'unix-socket' : String(host ?? 'localhost'), port: port ?? null, allowed });
  if (!allowed) throw new Error(`G03 verification forbids non-loopback ${kind} connections`);
}
const socketConnect = net.Socket.prototype.connect;
net.Socket.prototype.connect = function (...input) {
  const args = Array.isArray(input[0]) ? input[0] : input;
  const option = args[0];
  if (option && typeof option === 'object') assertLocal('tcp', option.host, option.port, typeof option.path === 'string');
  else if (typeof option === 'string' && !/^\d+$/u.test(option)) assertLocal('tcp', undefined, undefined, true);
  else assertLocal('tcp', typeof args[1] === 'string' ? args[1] : undefined, option);
  return Reflect.apply(socketConnect, this, input);
};
const datagramSend = dgram.Socket.prototype.send;
dgram.Socket.prototype.send = function (...args) {
  const values = args.slice(1).filter((value) => typeof value !== 'function');
  const address = typeof values.at(-1) === 'string' ? values.at(-1) : undefined;
  const port = address === undefined ? values.at(-1) : values.at(-2);
  assertLocal('udp', address, port);
  return Reflect.apply(datagramSend, this, args);
};
syncBuiltinESMExports();
record({ event: 'installed', policy: 'node-sockets-loopback-only-v1' });
