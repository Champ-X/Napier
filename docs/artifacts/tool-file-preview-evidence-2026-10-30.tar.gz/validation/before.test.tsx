import { createHash } from "node:crypto";
import { parseHTML } from "linkedom";
import { createRoot, type Root } from "react-dom/client";
import { act } from "react-dom/test-utils";
import { afterEach, expect, it, vi } from "vitest";
import { WorkspaceFileInspector } from "../src/WorkspaceFileInspector";
import type { WorkspaceFilePreview } from "../src/workspace-directory-api";

const roots: Root[] = [];
afterEach(async () => {
  for (const root of roots.splice(0)) await act(async () => root.unmount());
  vi.unstubAllGlobals();
});
const hash = createHash("sha256").update("x").digest("hex");
function binding() {
  return { sourceEventId: "event_one", receipt: {
    threadId: "thread_one", runId: "run_one", operationId: "call_one", path: "report.txt",
    fileSha256: hash, fileBytes: 1, toolName: "research_source" as const,
    action: "verify_report" as const, materialization: "observed" as const, evidence: "Report bytes verified.",
  }};
}
function preview(): WorkspaceFilePreview {
  return { path: "/workspace/report.txt", filename: "report.txt", contentType: "text/plain", text: "x", blob: new Blob(["x"]), sizeBytes: 1, sha256: hash };
}
function dom() {
  const parsed = parseHTML('<html><body><div id="root"></div></body></html>');
  for (const [key, value] of Object.entries({ document: parsed.document, window: parsed.window, navigator: parsed.window.navigator,
    HTMLElement: parsed.window.HTMLElement, Event: parsed.window.Event, IS_REACT_ACT_ENVIRONMENT: true })) vi.stubGlobal(key, value);
  const container = parsed.document.querySelector("#root") as HTMLElement;
  const root = createRoot(container); roots.push(root); return { container, root };
}
async function until(assertion: () => boolean) {
  for (let i = 0; i < 30; i++) { if (assertion()) return; await act(async () => Promise.resolve()); }
  throw new Error("Preview did not settle");
}
it("shows recorded integrity only after a bound tool file's verified bytes load", async () => {
  const { root, container } = dom();
  await act(async () => root.render(<WorkspaceFileInspector path="report.txt" threadId="thread_one" expectedSha256={hash}
    {...{toolFileBinding:binding()}} onClose={()=>undefined} onContinueEditing={()=>undefined} previewFile={async()=>preview()} />));
  await until(()=>container.textContent?.includes("1 bytes") === true);
  expect(container.textContent).toContain("File integrity recorded");
  expect(container.textContent).not.toContain("File verification pending");
});
