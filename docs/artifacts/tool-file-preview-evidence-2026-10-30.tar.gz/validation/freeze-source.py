from pathlib import Path
import subprocess,hashlib,json,difflib,shutil
root=Path('/tmp/napier-g01-tool-preview-binding-20261030')
repo=Path('/Users/champ/orca/Napier'); base='a52fe203348ac515bfbedb866f53346350890e61'
out=Path('/tmp/napier-g01-tool-preview-delivery-20261030');out.mkdir(exist_ok=True)
paths=['apps/web/src/AppWorkspaceViews.tsx','apps/web/src/WorkspaceFileInspector.tsx','apps/web/src/tool-file-preview-binding.ts','apps/web/test/tool-file-preview-binding.test.tsx','apps/web/test/tool-file-preview-targets.test.ts']
sha=lambda b:hashlib.sha256(b).hexdigest()
tracked={}
for row in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',base]).split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1); mode,kind,digest=meta.decode().split()
 if kind=='blob':tracked[p.decode()]=(mode,digest)
changes=[]
for p,(mode,digest) in tracked.items():
 f=root/p
 if not f.exists():changes.append({'path':p,'kind':'missing'});continue
 if f.is_symlink():data=str(f.readlink()).encode()
 else:data=f.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=digest:changes.append({'path':p,'kind':'modified'})
assert {x['path'] for x in changes}==set(paths[:2]),changes
patch=[]; manifest={}
for p in paths:
 data=(root/p).read_bytes(); old=subprocess.check_output(['git','-C',str(repo),'show',base+':'+p]) if p in tracked else b''
 patch.append('diff --git a/'+p+' b/'+p+'\n')
 if p not in tracked:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+p if p in tracked else '/dev/null',tofile='b/'+p))
 dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 manifest[p]={'baseSha256':sha(old) if old else None,'sha256':sha(data),'bytes':len(data)}
(out/'candidate.patch').write_text(''.join(patch))
original=json.loads(Path('/tmp/napier-g01-tool-output-root-source-commit-20261030.json').read_text())['sourceManifest']['files']
assert all(sha((root/p).read_bytes())==h for p,h in original.items())
(out/'source-manifest.json').write_text(json.dumps({'baseCommit':base,'snapshot':str(root),'trackedChanges':changes,'files':manifest,'patchSha256':sha((out/'candidate.patch').read_bytes()),'originalSource30Unchanged':True},indent=2)+'\n')
print(json.dumps({'directory':str(out),'patchSha256':sha((out/'candidate.patch').read_bytes()),'sourceFiles':len(manifest),'originalSource30Unchanged':True}))
