import { rm } from 'node:fs/promises';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { accountingFixture } from '/tmp/napier-g03-allowance-base-20261030/packages/runtime/test/model-accounting-fixture.ts';
import { LocalStore } from '/tmp/napier-g03-allowance-base-20261030/packages/runtime/src/store.ts';
import { canonicalJson } from '/tmp/napier-g03-allowance-base-20261030/packages/runtime/src/ed25519.ts';

const cleanup: Array<()=>Promise<void>>=[];
beforeEach(()=>vi.stubGlobal('fetch',()=>{throw new Error('External provider forbidden');}));
afterEach(async()=>{vi.restoreAllMocks();vi.unstubAllGlobals();for(const f of cleanup.splice(0).reverse()) await f();});
async function fixture(){const f=await accountingFixture();cleanup.push(async()=>{f.store.close();f.source.close();await rm(f.root,{recursive:true,force:true});});return f;}

it('duplicate reconciliation reports the committed revision if another Store settles after queue refresh',async()=>{
 const f=await fixture(),call=await f.main(),physical=await f.physical(call);
 const other=new LocalStore(f.options);await other.initializeAccounting();other.modelAccountingRepository.configureSource({source:f.source});cleanup.push(async()=>other.close());
 const raw=other as any,refresh=raw.refreshStateFromLedger.bind(other);
 const staleRevision=raw.mutableRun(f.parent.run.id).accounting.revision;
 let committed: Awaited<ReturnType<typeof f.store.modelAccountingRepository.reconcile>>|undefined;
 // Deterministic interleaving seam: another process may commit between the queue's
 // heap refresh and its subsequent coherent ledger claim read. No claim or fold is mocked.
 vi.spyOn(raw,'refreshStateFromLedger').mockImplementationOnce(()=>refresh()).mockImplementationOnce(async()=>{refresh();committed=await f.store.modelAccountingRepository.reconcile(physical.delivery);});
 const duplicate=await other.modelAccountingRepository.reconcile(physical.delivery);
 const durable=await other.modelAccountingRepository.readRunAccounting(f.parent.run.id);
 expect(duplicate.outcome).toBe('duplicate');expect(durable.accountingRevision).toBe(committed!.accountingRevision);
 expect(durable.accountingRevision).toBeGreaterThan(staleRevision);
 expect(duplicate.accountingRevision).toBe(durable.accountingRevision);
});
