import { rm } from 'node:fs/promises';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { accountingFixture } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/test/model-accounting-fixture.ts';
import { LocalStore } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/src/store.ts';
import { modelRunBudgetExposure } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/src/model-run-budget-exposure.ts';
import { normalizeModelPhysicalObservation, projectModelObservationUsage } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/src/model-usage-observation.ts';
import { canonicalJson } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/src/ed25519.ts';
import type { ModelAccountingHost } from '/tmp/napier-g03-allowance-verify-20261030/packages/runtime/src/model-accounting-host.ts';

const cleanup: Array<()=>Promise<void>>=[];
beforeEach(()=>vi.stubGlobal('fetch',()=>{throw new Error('External provider forbidden');}));
afterEach(async()=>{vi.restoreAllMocks();vi.unstubAllGlobals();for(const f of cleanup.splice(0).reverse()) await f();});
async function fixture(){const f=await accountingFixture();cleanup.push(async()=>{f.store.close();f.source.close();await rm(f.root,{recursive:true,force:true});});return f;}

it.each(['missing_cost','partial_below','partial_above'] as const)('settles independent dimensions without negative allowance: %s',async(mode)=>{
 const f=await fixture(),call=await f.main();await f.store.modelAccountingRepository.enter(call.prepared);f.source.reserve(call.attribution);
 const message=structuredClone(f.fixture.message);
 if(mode==='missing_cost') delete (message.usage as any).cost;
 else {delete (message.usage as any).input; delete (message.usage as any).totalTokens;message.usage.cost={input:0,output:mode==='partial_above'?1:0.00001,cacheRead:0,cacheWrite:0,total:mode==='partial_above'?1:0.00001};}
 const observation=normalizeModelPhysicalObservation({attribution:call.attribution,message,terminal:'response'});
 const projected=projectModelObservationUsage(call.attribution,observation),allowance=call.attribution.budgetAllowance!;
 f.source.record(observation);const delivery=f.source.pending()[0]!;
 await f.store.modelAccountingRepository.reconcile(delivery);
 const before=canonicalJson(modelRunBudgetExposure(f.store as unknown as ModelAccountingHost,f.parent.run.id));
 await f.store.modelAccountingRepository.reconcile(delivery);
 const exposure=modelRunBudgetExposure(f.store as unknown as ModelAccountingHost,f.parent.run.id);
 expect(canonicalJson(exposure)).toBe(before);
 expect(exposure.accountedTokens).toBe(projected.budgetTokens);
 expect(exposure.accountedCostUsd).toBe(projected.budgetCostUsd??projected.usage.costUsd);
 expect(exposure.reservedTokens).toBe(mode==='missing_cost'?0:Math.max(0,allowance.budgetTokens-projected.budgetTokens));
 expect(exposure.reservedCostUsd).toBeCloseTo(Math.max(0,allowance.budgetCostUsd!-(projected.budgetCostUsd??projected.usage.costUsd)),12);
 if(mode==='missing_cost'){expect(projected.tokenCompleteness).toBe('complete');expect(projected.budgetCostCompleteness).toBe('incomplete');expect(exposure.reservedCostUsd).toBeGreaterThan(0);}
 if(mode==='partial_above'){expect(exposure.accountedCostUsd).toBe(1);expect(exposure.reservedCostUsd).toBe(0);expect(exposure.reservedTokens).toBeGreaterThan(0);}
});

it('ancestor exposure counts entered native children once, excludes preparation, and rejects malformed graph links',async()=>{
 const f=await fixture(),a=await f.child(),b=await f.child();const ca=await a.prepare(),cb=await b.prepare();
 await f.store.modelAccountingRepository.enter(ca.prepared);
 const host=f.store as unknown as ModelAccountingHost;
 const prior=modelRunBudgetExposure(host,f.parent.run.id);
 expect(prior.accountedTokens).toBe(0);expect(prior.reservedTokens).toBe(ca.attribution.budgetAllowance!.budgetTokens);
 await f.store.modelAccountingRepository.enter(cb.prepared);
 const next=modelRunBudgetExposure(host,f.parent.run.id);
 expect(next.reservedTokens).toBe(ca.attribution.budgetAllowance!.budgetTokens+cb.attribution.budgetAllowance!.budgetTokens);
 const fake={...host,state:{...host.state,subagents:[...host.state.subagents].reverse()},mutableRun:host.mutableRun.bind(host),requireLedger:host.requireLedger.bind(host)} as ModelAccountingHost;
 expect(modelRunBudgetExposure(fake,f.parent.run.id)).toEqual(next);
 fake.state={...fake.state,subagents:fake.state.subagents.map(t=>t.id===a.task.id?{...t,childRunId:b.child.run.id}:t)};
 expect(()=>modelRunBudgetExposure(fake,f.parent.run.id)).toThrow('child lineage');
});

it('duplicate reconciliation reports the committed revision if another Store settles after queue refresh',async()=>{
 const f=await fixture(),call=await f.main(),physical=await f.physical(call);
 const other=new LocalStore(f.options);await other.initializeAccounting();other.modelAccountingRepository.configureSource({source:f.source});cleanup.push(async()=>other.close());
 const raw=other as any,refresh=raw.refreshStateFromLedger.bind(other);
 const staleRevision=raw.mutableRun(f.parent.run.id).accounting.revision;
 let committed: Awaited<ReturnType<typeof f.store.modelAccountingRepository.reconcile>>|undefined;
 // Deterministic interleaving seam: another process may commit between the queue's
 // heap refresh and its subsequent coherent ledger claim read. No claim or fold is mocked.
 vi.spyOn(raw,'refreshStateFromLedger').mockImplementationOnce(()=>refresh()).mockImplementationOnce(async()=>{refresh();committed=await f.store.modelAccountingRepository.reconcile(physical.delivery);});
 const duplicate=await other.modelAccountingRepository.reconcile(physical.delivery);
 const durable=await other.modelAccountingRepository.readRunAccounting(f.parent.run.id);
 expect(duplicate.outcome).toBe('duplicate');expect(durable.accountingRevision).toBe(committed!.accountingRevision);
 expect(durable.accountingRevision).toBeGreaterThan(staleRevision);
 expect(duplicate.accountingRevision).toBe(durable.accountingRevision);
});
