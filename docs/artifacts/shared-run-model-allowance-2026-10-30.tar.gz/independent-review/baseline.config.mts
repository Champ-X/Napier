import base from './baseline-alias.config.mts';
export default {...base, root: '/tmp/napier-g03-adversarial-20261030', test: {...base.test, include: ['baseline-reconciliation.test.ts'], reporters: ['default', 'json'], outputFile: {json: '/tmp/napier-g03-adversarial-20261030/baseline-results-v1.json'}}};
