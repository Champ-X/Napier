from pathlib import Path
import os,json,subprocess,datetime,hashlib
snapshot=Path('/tmp/napier-g03-allowance-verify-20261030')
out=Path('/tmp/napier-g03-shared-allowance-docs-20261030/network')
node=str(Path('/Users/champ/orca/Napier/node_modules/.bin/node').resolve()) if Path('/Users/champ/orca/Napier/node_modules/.bin/node').exists() else 'node'
checks=[]
def run(name,args,env=None):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('wb') as log: result=subprocess.run(args,cwd=snapshot,env=env,stdout=log,stderr=subprocess.STDOUT)
 check={'name':name,'argv':args,'cwd':str(snapshot),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'log':name+'.log'}
 checks.append(check);(out/'commands.json').write_text(json.dumps(checks,indent=2)+'\n')
 if result.returncode:raise RuntimeError(name+' failed: '+str(result.returncode))
def manifest(roots):
 rows=[]
 for relative in roots:
  for file in sorted((snapshot/relative).rglob('*')):
   if file.is_file():
    data=file.read_bytes();rows.append({'path':str(file.relative_to(snapshot)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 return rows
run('contracts-build',[node,'node_modules/typescript/bin/tsc','-p','packages/contracts/tsconfig.json'])
run('runtime-build',[node,'node_modules/typescript/bin/tsc','-p','packages/runtime/tsconfig.json'])
run('strict-test-types',[node,'node_modules/typescript/bin/tsc','-p','tsconfig.g03-tests.json','--noEmit'])
(snapshot/'tsconfig.g03-tests.json').read_bytes()
(out/'strict-test-types.json').write_bytes((snapshot/'tsconfig.g03-tests.json').read_bytes())
(out/'emitted-before.json').write_text(json.dumps(manifest(['packages/contracts/dist','packages/runtime/dist']),indent=2)+'\n')
env={**os.environ,'NODE_OPTIONS':(os.environ.get('NODE_OPTIONS','')+' --import '+str(out/'network-guard.mjs')).strip(),'NAPIER_G03_NETWORK_AUDIT':str(out/'selfcheck-network.jsonl')}
code="import net from 'node:net';let denied=false;try{net.connect({host:'203.0.113.1',port:9})}catch(e){denied=String(e).includes('forbids non-loopback')}if(!denied)throw new Error('External guard did not deny');console.log(JSON.stringify({deniedBeforeConnect:true}));"
run('guard-selfcheck',[node,'--input-type=module','-e',code],env)
env['NAPIER_G03_NETWORK_AUDIT']=str(out/'network.jsonl')
files=json.loads((out/'test-files.json').read_text())
run('guarded-tests',[node,'node_modules/vitest/vitest.mjs','run',*files,'--maxWorkers=2','--testTimeout=10000','--reporter=default','--reporter=json','--outputFile.json='+str(out/'results.json')],env)
(out/'emitted-after.json').write_text(json.dumps(manifest(['packages/contracts/dist','packages/runtime/dist']),indent=2)+'\n')
print(json.dumps({'checks':len(checks),'exitCodes':[c['exitCode'] for c in checks]}))
