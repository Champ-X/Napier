import { DatabaseSync } from 'node:sqlite';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';

const source = JSON.parse(readFileSync('/tmp/napier-g07-mailbox-baseline-20261030/inspect-explain-v1.json', 'utf8'));
const db = new DatabaseSync(source.database, { readOnly: true });
const variants = {
  current: { sql: source.sql, args: source.args },
  forcedTyped: { sql: source.sql.replace('FROM ledger_events WHERE', 'FROM ledger_events INDEXED BY ledger_events_thread_type_seq WHERE'), args: source.args },
  mergeTypes: {
    sql: 'SELECT event_json FROM (SELECT seq,event_json FROM ledger_events WHERE thread_id=? AND seq BETWEEN ? AND ? AND event_type=? UNION ALL SELECT seq,event_json FROM ledger_events WHERE thread_id=? AND seq BETWEEN ? AND ? AND event_type=?) ORDER BY seq ASC',
    args: [...source.args.slice(0,3), source.args[3], ...source.args.slice(0,3), source.args[4]],
  },
};
const results = {};
for (const [name, v] of Object.entries(variants)) {
  results[name] = { plan: db.prepare('EXPLAIN QUERY PLAN ' + v.sql).all(...v.args), samplesMs: [], rows: undefined, sha256: undefined };
  v.statement = db.prepare(v.sql);
}
const order = [];
for (let i=0; i<8; i++) {
  const names = i % 2 === 0 ? Object.keys(variants) : Object.keys(variants).reverse();
  order.push(names);
  for (const name of names) {
    const v = variants[name];
    const t = performance.now();
    const rows = v.statement.all(...v.args);
    const elapsed = performance.now() - t;
    const hash = createHash('sha256').update(JSON.stringify(rows)).digest('hex');
    if (results[name].sha256 && results[name].sha256 !== hash) throw new Error('Rows changed');
    results[name].sha256 = hash;
    results[name].rows = rows.length;
    results[name].samplesMs.push(elapsed);
  }
}
db.close();
if (new Set(Object.values(results).map(r => r.sha256)).size !== 1) throw new Error('Query results differ');
const report = { source, readOnly: true, node: process.version, order, results,
  scope: 'Read-only sparse 100k-noise database; same rows. Diagnostic only, no production SQL change or dense-cardinality acceptance.' };
writeFileSync('/tmp/napier-g07-mailbox-sql-plan-probe-20261030.json', JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
