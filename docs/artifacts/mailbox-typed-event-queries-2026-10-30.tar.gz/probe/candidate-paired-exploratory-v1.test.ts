import { mkdir,readFile,writeFile,copyFile } from 'node:fs/promises';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { it,expect,vi } from 'vitest';
import { LocalStore } from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/packages/runtime/src/store.ts';
import { canonicalJson,sha256 } from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/packages/runtime/src/ed25519.ts';
import { InProcessSubagentProvider } from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/packages/runtime/src/in-process-subagent-provider.ts';
import { continuationMailbox } from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/packages/runtime/src/subagent-continuation-mailbox.ts';
import { projectSubagentMailbox } from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/packages/runtime/src/subagent-mailbox-projection.ts';
const root='/tmp/napier-g07-mailbox-frozen-20261030',variant='candidate';
it('compares frozen native mailbox paths with full replay',async()=>{
 vi.stubGlobal('fetch',()=>{throw new Error('External calls forbidden');});
 const f=JSON.parse(await readFile(path.join(root,'seed-context.json'),'utf8')),child=f.child,messages=f.messages;
 const results:any[]=[];
 try{for(const count of [100,10_000,100_000]){
  const dataRoot=path.join(root,`${variant}-data-${count}`);await mkdir(dataRoot,{recursive:true});await copyFile(path.join(root,`seed-${count}`,'ledger.sqlite'),path.join(dataRoot,'ledger.sqlite'));
  const store=new LocalStore({dataRoot,workspaceRoot:f.options.workspaceRoot});await store.initialize();
  try{
   await store.renewRunLease(f.parent.run.id,f.parent.token,600_000);await store.renewRunLease(child.child.run.id,child.child.token,600_000);
   const host=store as any,ledger=host.requireLedger(),native=ledger.listRunEvents.bind(ledger),all=store.listEvents.bind(store),range=store.listEventsRange.bind(store);
   const fullEvents=await all(f.thread.id);
   const task=store.listSubagentTasks(f.thread.id).find(t=>t.id===child.task.id)!,run=store.listRuns(f.thread.id).find(r=>r.id===task.childRunId)!;
   const replayHost={state:host.state,requireLedger:()=>({listRunEvents:(id:string)=>native(id)})};
   const replay=continuationMailbox(replayHost as any,run,task),display=projectSubagentMailbox(task,store.listSubagentTasks(f.thread.id),fullEvents);
   let traces:any[]=[];
   vi.spyOn(ledger,'listRunEvents').mockImplementation((...args:any[])=>{const started=performance.now();const value=native(...args);traces.push({api:'ledger.listRunEvents',runId:args[0],afterSeq:args[1]??0,types:args[2]??null,rows:value.length,ms:performance.now()-started});return value;});
   vi.spyOn(store,'listEvents').mockImplementation(async(...args:any[])=>{const started=performance.now();const value=await all(...args);traces.push({api:'store.listEvents',threadId:args[0],rows:value.length,ms:performance.now()-started});return value;});
   vi.spyOn(store,'listEventsRange').mockImplementation(async(...args:any[])=>{const started=performance.now();const value=await range(...args);traces.push({api:'store.listEventsRange',threadId:args[0],fromSeq:args[1],toSeq:args[2],types:args[3]??null,rows:value.length,ms:performance.now()-started});return value;});
   const provider=new InProcessSubagentProvider({store,profile:f.profile,run:f.parent.run} as any);
   const handle={kind:'napier.subagent-handle',schemaVersion:1,providerId:'in_process',taskId:child.task.id,executionId:child.task.executionId!} as const;
   async function measure(name:string,iteration:number,action:()=>Promise<any>|any){traces=[];const cpu=process.cpuUsage(),started=performance.now();const output=await action();const wallMs=performance.now()-started,used=process.cpuUsage(cpu);results.push({variant,noiseEvents:count,name,iteration,wallMs,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000,rss:process.memoryUsage().rss,rows:traces.reduce((sum,t)=>sum+t.rows,0),traces,outputSha256:sha256(canonicalJson(output))});return output;}
   // One warm-up is excluded; retained samples exercise real Store/provider entrypoints.
   await store.prepareSubagentChildCheckpoint(child.fence);await store.acceptSubagentMessage({taskId:child.task.id,executionId:child.task.executionId!,message:messages[0]});await provider.inspect(handle);
   for(let i=0;i<5;i++){
    const prepared=await measure('prepare_checkpoint',i,()=>store.prepareSubagentChildCheckpoint(child.fence));expect(prepared.mailbox.accepted).toEqual(replay.accepted);
    const duplicate=await measure('accept_duplicate',i,()=>store.acceptSubagentMessage({taskId:child.task.id,executionId:child.task.executionId!,message:messages[0]}));expect(duplicate.appended).toBe(false);
    const view=await measure('inspect',i,()=>provider.inspect(handle));expect(view.mailbox).toEqual(display);
    const folded=await measure('continuation_mailbox',i,()=>{const value=continuationMailbox(host,run,task);return {accepted:value.accepted,messages:[...value.messages]};});expect(folded).toEqual({accepted:replay.accepted,messages:[...replay.messages]});
   }
   await writeFile(path.join(root,`${variant}-measurements-v1.json`),JSON.stringify(results,null,2)+'\n');
  }finally{vi.restoreAllMocks();await store.shutdown();}
 }}finally{vi.unstubAllGlobals();}
},120_000);
