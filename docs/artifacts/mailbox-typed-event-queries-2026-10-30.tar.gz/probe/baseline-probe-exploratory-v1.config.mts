import base from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/vitest.config.mts';
export default {...base,root:'/tmp/napier-g07-mailbox-frozen-20261030',test:{...base.test,include:['baseline-paired.test.ts'],maxWorkers:1,reporters:['default','json'],outputFile:{json:'/tmp/napier-g07-mailbox-frozen-20261030/baseline-result-v1.json'}}};
