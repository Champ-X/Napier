import base from '/tmp/napier-g07-mailbox-frozen-20261030/candidate/vitest.config.mts';
export default {...base,root:'/tmp/napier-g07-mailbox-frozen-20261030',test:{...base.test,include:['candidate-paired.test.ts'],maxWorkers:1,reporters:['default','json'],outputFile:{json:`/tmp/napier-g07-mailbox-frozen-20261030/candidate-${process.env.G07_MEASUREMENT_ROUND??'exploratory'}-result-v3.json`}}};
