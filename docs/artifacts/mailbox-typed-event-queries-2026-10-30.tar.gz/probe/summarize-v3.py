from pathlib import Path
import json,hashlib,statistics,sqlite3,subprocess
r=Path('/tmp/napier-g07-mailbox-frozen-20261030');repo=Path('/Users/champ/orca/Napier')
order=[('baseline','round1'),('candidate','round2'),('candidate','round3'),('baseline','round4')];rows=[]
for variant,round in order:rows.extend(json.loads((r/f'{variant}-{round}-measurements-v3.json').read_text()))
summaries=[]
for count in [100,10000,100000]:
 for name in ['prepare_checkpoint','accept_duplicate','inspect','continuation_mailbox']:
  group=[x for x in rows if x['noiseEvents']==count and x['name']==name]
  result={'noiseEvents':count,'operation':name,'completeOutputHashIdentical':len({x['outputSha256'] for x in group})==1,'outputSha256':group[0]['outputSha256']}
  for variant in ['baseline','candidate']:
   subset=[x for x in group if x['variant']==variant]
   result[variant]={'samples':len(subset),'returnedRows':sorted({x['rows'] for x in subset}),'wallMsMedian':statistics.median(x['wallMs'] for x in subset),'wallMsRange':[min(x['wallMs'] for x in subset),max(x['wallMs'] for x in subset)],'cpuMsMedian':statistics.median(x['cpuUserMs']+x['cpuSystemMs'] for x in subset),'boundaryRssBytesRange':[min(x['rss'] for x in subset),max(x['rss'] for x in subset)],'roundMedianWallMs':{round:statistics.median(x['wallMs'] for x in subset if x['round']==round) for _,round in order if any(x['round']==round for x in subset)}}
  assert result['completeOutputHashIdentical'];summaries.append(result)
def hashfile(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def event_identity(p):
 db=sqlite3.connect(f'file:{p}?mode=ro',uri=True);h=hashlib.sha256();n=0
 for row in db.execute('select event_json from ledger_events order by thread_id,seq'):
  h.update(row[0].encode());h.update(b'\n');n+=1
 db.close();return {'events':n,'orderedEventJsonSha256':h.hexdigest()}
seeds=[]
for count in [100,10000,100000]:
 p=r/f'seed-v3-{count}'/'ledger.sqlite';identity=event_identity(p);copies=[]
 for variant,round in order:
  clone=r/f'{variant}-{round}-v3-data-{count}'/'ledger.sqlite';other=event_identity(clone);assert other==identity
  copies.append({'variant':variant,'round':round,'eventIdentityMatches':True})
 seeds.append({'noiseEvents':count,'databasePath':str(p),'databaseFileSha256':hashfile(p),**identity,'copies':copies})
manifest=json.loads((r/'candidate-manifest.json').read_text())
for e in manifest['paths']:
 assert hashfile(repo/e['path'])==e['sha256'];assert hashfile(r/'candidate'/e['path'])==e['sha256']
source=[]
for tree in ['baseline','candidate']:
 entries=[]
 for package in ['contracts','runtime']:
  for p in sorted((r/tree/'packages'/package).rglob('*.ts')):
   if '/dist/' in str(p):continue
   entries.append({'path':str(p.relative_to(r/tree)),'sha256':hashfile(p)})
 (r/f'{tree}-source-tree-manifest.json').write_text(json.dumps(entries,indent=2)+'\n');source.append({'variant':tree,'sourceFiles':len(entries),'manifestSha256':hashfile(r/f'{tree}-source-tree-manifest.json')})
receipt={'status':'implemented_and_locally_verified','baseCommit':'03a62a0f9ef634c6f38d09196917193e47e83f62','workingHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'sourceOwnershipManifest':str(r/'candidate-manifest.json'),'sourceManifests':source,'lockSha256':hashfile(r/'candidate/package-lock.json'),'executionOrder':[{'variant':v,'round':n} for v,n in order],'samplesPerVariantPerScale':10,'warmupsPerRoundPerScale':1,'seedMethod':'production native bootstrap, all-thread summary replay, production normalized lease overlay, closed SQLite copies; seed and Store initialize excluded from measurements','providerDispatches':0,'externalFetchForbidden':True,'seeds':seeds,'measurements':summaries,'validation':{'baselineCompileExitCode':0,'candidateCompileExitCode':0,'frozenRegression':{'suites':16,'cases':146,'passed':146,'artifact':'candidate-regression-v1.json'},'newTestStrictRecheckExitCode':0,'newTestFinalRecheck':{'cases':8,'passed':8,'artifact':'new-test-regression-v2.json'}},'limits':['Native query return counts are measured. Event JSON decode reduction follows one parse per returned row in unchanged query implementation; decoder CPU was not separately profiled.','No SQLite virtual-machine instruction or B-tree visit counters were collected. EXPLAIN shows multi-type thread query still scans the thread/seq index.','Child frontier remains a full child-run read; no cursor/cache or SQL planner change is included.','Sparse mailbox workload has two accepted messages and one delivery; it does not establish dense-mailbox, multi-lineage, concurrent-load, or broad G07 performance acceptance.','Boundary process RSS includes fixture setup, warmup and earlier scales; it is neither peak memory nor leak evidence.','No cold disk or multi-session statistical claim; balanced process order was baseline,candidate,candidate,baseline.','Frozen source trees use installed third-party dependencies via symlinks, with per-tree @napier packages and built dist.','Initial full regression used the same8-case new test before a guarded JsonValue assertion; final strict+8 recheck cover only this test typing change.'],'retainedFailures':[{'path':'/tmp/napier-g07-mailbox-baseline-20261030/run-v1.log','cause':'Harness seeded only target-thread events although snapshot contained additional threads.'},{'path':'candidate-paired-v1.log','cause':'Harness omitted normalized lease table overlay from seed; snapshot lease expired before candidate initialize.'},{'path':'baseline-round1-v2.log','cause':'Same normalized lease overlay omission; preserved and superseded by v3 BCCB.'},{'path':'/tmp/napier-g07-mailbox-root-review-20261030/strict.log','cause':'New test accessed broad JsonValue without an object guard; corrected without production changes.'}]}
(r/'review-receipt-v3.json').write_text(json.dumps(receipt,indent=2)+'\n')
artifacts=['candidate-manifest.json','baseline-source-tree-manifest.json','candidate-source-tree-manifest.json','review-receipt-v3.json','seed.test.ts','seed-probe.config.mts','seed-result-v3.json','seed-run-v3.log','baseline-compile-v1.log','candidate-compile-v1.log','candidate-regression-v1.log','candidate-regression-v1.json','new-test-strict-v2.log','new-test-regression-v2.log','new-test-regression-v2.json','summarize-v3.py']
for v,n in order:artifacts.extend([f'{v}-{n}-measurements-v3.json',f'{v}-{n}-v3.log',f'{v}-{n}-result-v3.json'])
for v in ['baseline','candidate']:artifacts.extend([f'{v}-paired.test.ts',f'{v}-probe.config.mts'])
(r/'evidence-manifest-v3.json').write_text(json.dumps([{'path':p,'sha256':hashfile(r/p),'bytes':(r/p).stat().st_size} for p in artifacts],indent=2)+'\n')
print(json.dumps({'receipt':str(r/'review-receipt-v3.json'),'sha256':hashfile(r/'review-receipt-v3.json'),'candidateManifestSha256':hashfile(r/'candidate-manifest.json'),'evidenceManifestSha256':hashfile(r/'evidence-manifest-v3.json'),'sourceFiles':source},indent=2))
