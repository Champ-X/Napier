import { mkdir,writeFile } from 'node:fs/promises';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { it,expect,vi } from 'vitest';
import { applyNormalizedRunLeases } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/run-lease-state.ts';
import { accountingFixture } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/test/model-accounting-fixture.ts';
import { LocalStore } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/store.ts';
import { SqliteLedger } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/sqlite-ledger.ts';
import { issueModelUndispatchedDriverProof } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/model-call-attribution.ts';
import { canonicalJson,sha256 } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/ed25519.ts';
import { applyThreadSummaryEvent,replayThreadSummaryTails } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/store-thread-summary-projection.ts';
import { resolveRegisteredEventInput } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/run-event-registry.ts';
import { InProcessSubagentProvider } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/in-process-subagent-provider.ts';
import { continuationMailbox } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/subagent-continuation-mailbox.ts';
import { projectSubagentMailbox } from '/tmp/napier-g07-mailbox-frozen-20261030/baseline/packages/runtime/src/subagent-mailbox-projection.ts';

const root='/tmp/napier-g07-mailbox-frozen-20261030';
it('measures native mailbox scans without any provider dispatch',async()=>{
 vi.stubGlobal('fetch',()=>{throw new Error('External calls forbidden');});
 const f=await accountingFixture(),child=await f.child();
 await f.store.modelAccountingRepository.closeUndispatchedChildInvocation(issueModelUndispatchedDriverProof(child.authority),'mailbox_baseline_no_model');
 function message(id:string,text:string){const body={kind:'napier.subagent-message',schemaVersion:1,id,taskId:child.task.id,messageKind:'steering',text,createdAt:new Date().toISOString()};return {...body,contentSha256:sha256(canonicalJson(body))};}
 const messages=[message('submsg_baseline0001','Constraint A'),message('submsg_baseline0002','Constraint B')];
 for(const message of messages) await f.store.acceptSubagentMessage({taskId:child.task.id,executionId:child.task.executionId!,message:message as any});
 await f.store.appendEvent({threadId:f.thread.id,runId:f.parent.run.id,type:'subagent.message.delivered',category:'subagent',payload:{taskId:child.task.id,executionId:child.task.executionId!,messageId:messages[1]!.id,messageKind:'steering',contentSha256:messages[1]!.contentSha256}});
 await f.store.renewRunLease(f.parent.run.id,f.parent.token,600_000);await f.store.renewRunLease(child.child.run.id,child.child.token,600_000);
 const templateEvents=(await Promise.all(f.store.listThreads().map(t=>f.store.listEvents(t.id)))).flat();
 const snapshot=(f.store as any).requireLedger().readSnapshot();const original=JSON.parse(snapshot.stateJson);applyNormalizedRunLeases(original.runs,snapshot.runLeases);
 replayThreadSummaryTails({threads:original.threads,expectedEventCount:snapshot.revision-snapshot.snapshotRevision,listEvents:(threadId:string,afterSeq:number)=>templateEvents.filter(e=>e.threadId===threadId&&e.seq>afterSeq)});
 await f.store.shutdown();f.source.close();
 for(const count of [100,10_000,100_000]){
  const state=structuredClone(original),events=structuredClone(templateEvents),thread=state.threads.find((t:any)=>t.id===f.thread.id);
  const seq=thread.eventCount,epoch=Date.parse(thread.updatedAt);
  for(let n=0;n<count;n++){
   const checked=resolveRegisteredEventInput({threadId:f.thread.id,runId:f.parent.run.id,type:'model.text.delta',category:'model',visibility:'hidden',payload:{delta:'x'.repeat(128),deltaBytes:128,chunkCount:1}});
   const event={id:`event_mailbox_${count}_${n}`,threadId:f.thread.id,runId:f.parent.run.id,seq:seq+n+1,type:checked.type,category:checked.category,visibility:checked.visibility,createdAt:new Date(epoch+n+1).toISOString(),payload:checked.payload,schemaVersion:checked.schemaVersion};
   applyThreadSummaryEvent(thread,event as any);events.push(event as any);
  }
  const dataRoot=path.join(root,`seed-v3-${count}`);await mkdir(dataRoot,{recursive:true});const seed=new SqliteLedger(path.join(dataRoot,'ledger.sqlite'));seed.initialize();seed.bootstrap(JSON.stringify(state),events);seed.close();

 }
 await writeFile(path.join(root,"seed-context-v3.json"),JSON.stringify({options:f.options,profile:f.profile,thread:f.thread,parent:f.parent,child:{task:child.task,child:child.child,fence:child.fence},messages},null,2)+"\n");
 vi.unstubAllGlobals();
},120_000);
