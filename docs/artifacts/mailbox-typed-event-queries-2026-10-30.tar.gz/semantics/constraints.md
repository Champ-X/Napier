# G07 mailbox typed-query and cursor constraints

Read-only source review of `/Users/champ/orca/Napier`, main `bf3b1c7843811766c70b66625f59b872c8806b79`. No production edits, build, model calls or repetition of invocation-context-cursor measurements. Parent owns native LocalStore measurements. This review establishes source constraints and an oracle proposal; it is not evidence of a measured performance improvement.

## Smallest safe typed-query slice

| Consumer | Existing semantics | Safe query reduction |
| --- | --- | --- |
| `continuationMailbox` | Reads each predecessor/current Task's parent Run, validates accepted messages, merges globally by accepted sequence and rejects duplicate inherited message IDs. | `listRunEvents(parentRunId, 0, ["subagent.message.accepted"])`; retain validation and lineage traversal. |
| `acceptSubagentMessage` | Finds an existing ID across the whole parent Run before checking whether new acceptance is still allowed. | Accepted events plus `RUN_TERMINAL_EVENT_TYPES`; preserve lookup scope and ordering. An identical retry after terminal returns its original event, while a new message is rejected. |
| `SubagentCheckpointRepository.commit` parent transcript input | `sdkToolReceipts` only accepts `subagent.step` with exact parent/thread/task/childRun/execution identity and `kind=tool`. | Parent `subagent.step` query is sufficient for transcript validation, separately from accepted mailbox query. |
| `InProcessSubagentProvider.inspect` | `projectSubagentMailbox` selects accepted/delivered by Task lineage IDs over the entire thread. It does not predicate on event.runId. | Thread-scoped accepted+delivered events, in the same sequence order. Do not silently narrow to parent Run IDs without a separate compatibility proof. |
| Child checkpoint/continuation frontier | Uses all child events for the all-event head, settled model/tool/effect evidence and forbidden tail checks. | Keep full child query in this slice. A later reduction requires an independent all-event head and a proven complete evidence set. |

The existing APIs already support `listRunEvents(runId, afterSeq, types)` and `listEventsRange(threadId, fromSeq, toSeq, types)` in sync SQLite and async worker paths. `SubagentChildRunHost.requireLedger` currently exposes only the first argument, so its narrow interface hides capability the concrete ledger has. Existing indexes cover `(run_id,event_type,seq)` and `(thread_id,event_type,seq)`; no new index is needed merely to return typed rows. `types=[]` must keep meaning empty result; `undefined` means all. Run afterSeq is exclusive and thread range endpoints are inclusive. `findLatestEvent` returns the latest, whereas durable terminal admission uses the FIRST terminal event.

A thread range needs a finite all-event upper bound. If head and event batch are read separately, make the chosen cut explicit and do not conflate it with a state snapshot. Avoid mixing an async reader's later snapshot with mutation-authority decisions currently made under the Store queue/CAS.

## Correctness oracle

Use the existing full-read helpers as the reference and run the SAME helpers over typed rows before introducing a cursor. Compare canonicalized accepted bindings, Map entries/messages, projection object, checkpoint frontier and consumption state; compare success/rejection and exact returned duplicate event identity for acceptance. Timing and row counts are separate evidence.

Required local cases:

1. Parent diagnostic/model noise interleaved with unrelated Task messages and the target Task messages; same return values before/after filtering.
2. Identical acceptance retried across two Stores, conflicting same message ID, and the same ID presented for a sibling Task in the same parent Run. A task-only ID lookup would weaken the current conflict scope.
3. Identical accepted retry after terminal returns `appended=false`; a new ID after any durable terminal rejects. First terminal wins; do not replace it with latest terminal lookup.
4. Sparse B-before-A consumption: consumedCount=1 but consumedThroughSeq=0; later A closes the prefix, while a third message with identical text is still a distinct ID. The existing test covers this explicitly.
5. Continuation chain with pending and already consumed inherited messages; successor delivery references current Task but inherited message identity. Same acceptedCount, deliveredCount, consumedCount, last timestamps and origin fields before/after cold reopen and replay validation.
6. Duplicate acceptance in strict mailbox input rejects; display projection still keeps its existing first-accepted/last-delivered dedup semantics. Unknown delivery IDs do not increment deliveredCount.
7. Cycle, depth32 boundary, unavailable predecessor, rewritten execution/parent identity and inherited capsule mismatch preserve existing errors rather than returning an empty mailbox.
8. A new accepted message after preparation, checkpoint-pointer mutation, child unrelated-event append, lease expiry, parent terminal race and changed Task/execution revision still reject or re-evaluate at the existing boundaries.
9. Returned objects are detached: mutating a query result, accepted list or message must not mutate a later read/cached state.
10. The optimized native checkpoint and continuation result must still validate through `validateThreadReplayBundle` / `assertReplaySubagentBindings`; no new private-state capability is created by a hash or public JSON copy.

## Cursor constraints, if added later

- Keep a separate scan watermark. `mailboxConsumedThroughSeq` is the contiguous consumed prefix, NOT a scan cursor or set of consumed IDs. The capsule's full consumed entries, exact hashes/origin and message indexes remain authoritative.
- A cache key needs Store/ledger identity, thread, current Task/execution and the resolved continuation lineage. A successor can inherit old events whose sequence is below a previous cursor; lineage change must reset/reseed, never merely continue after the old high-water mark.
- Snapshot Task consumption metadata independently. Checkpoint commit increments Task revision and consumed counters without a new accepted/delivered event; an event-only cache cannot cache the final projected mailbox object indefinitely.
- Process event batches in ascending thread sequence. Maintain first acceptance per message ID and last delivery per message ID; delivery retries do not increase counts. A cold full replay is the oracle at every prefix. Do not reuse the tolerant projection map as strict accepted-message authority.
- If supporting arbitrary replay inputs, retain unmatched deliveries until acceptance becomes visible: the current full fold joins accepted/delivered after collecting both maps. Do not drop unmatched entries only because acceptance is absent in one partial batch.
- Invalidate on restart/reopen, ledger replacement/import/replay-source change, cursor regression, changed lineage/identity, changed source capsule/checkpoint pointer, or any inability to prove prefix continuity. Store lifecycle identity is safer than runId alone.
- Queue/CAS conflicts must discard any unpublished append/cursor advancement. Advance cached state only from committed rows or a recorded coherent read cut. Duplicate retries must remain no-write/idempotent.
- Cache data and indexes may accelerate proof; they must not grant preparation/continuation authority. Private WeakMap handles, durable capsule readback, exact frontier equality, current leases and authorization checks still run.

## Identity and evidence boundaries

`acceptedSubagentMailbox` checks task/thread/parent-Run binding, message self-hash, ID format, timestamp and text bounds. Its accepted binding includes ID, acceptedSeq, contentSha256 and exact reconstructed user-message hash. Inherited entries also carry originTaskId/originParentRunId. Consumption cannot drop or rewrite prior entries and preserves messageIndex; same text is not same identity.

Continuation is bounded to32 nodes and binds Task/child Run/execution, predecessor receipt, target recovery parent and frozen configuration. `resolveSubagentLogicalIdentity` has stricter identity checks than `continuationMailbox` itself. The existing durable state validators establish those relations; a faster lookup must not bypass them or silently merge a Task-only and Run-receipt lineage that disagree.

Checkpoint `runHeadSeq` is the last ALL-event child sequence. `prepare` rechecks the checkpoint/capsule pointer after async private reads; `commit` rechecks durable capsule bytes, frontier equality, previous source/prompt/tools, exact transcript and consumption. Continuation preparation records source Run and parent all-event heads, mailbox snapshot hash, revisions and source capsule; claiming it rereads these guards under the queue. Typed parent mailbox access can preserve this without changing the child proof surface.

The UI-facing logical mailbox projection is intentionally more permissive than strict consumption authority. It deduplicates acceptance by first ID and delivery by last ID, joins only known accepted IDs, walks `continuedFromTaskId`, and inherits the nearest defined consumed counters. Its output omits message text. The Hub event fold is another projection with different counting mechanics; do not substitute it as an oracle without separate parity coverage.

## Source anchors

- `subagent-mailbox-state.ts:21` strict acceptance; `:36` sparse consumption; `:61` duplicate-before-terminal acceptance.
- `subagent-continuation-mailbox.ts:7` lineage/merge; `:35` inherited origin; `:41` completion requires consumption.
- `subagent-checkpoint-repository.ts:18` preparation; `:43` commit and revalidation.
- `subagent-checkpoint-frontier.ts:12` all-event head and unresolved-work guards.
- `subagent-checkpoint-transcript.ts:10` exact response/tool/user evidence; parent receipts only `subagent.step`.
- `subagent-continuation-repository.ts:32` re-evaluation and guarded claim; `subagent-continuation-evaluation.ts:56` source/tail/mailbox assessment.
- `subagent-continuation-lineage.ts:5` logical identity; `:72` durable predecessor and source validation.
- `subagent-mailbox-projection.ts:5` display fold; `in-process-subagent-provider.ts:163` full-thread inspect call.
- `sqlite-ledger-query.ts:23` typed Run read; `:38` inclusive typed thread range; `run-event-query-port.ts:5` scope contract.
- `subagent-replay-validation.ts:112` replay identity/accounting/checkpoint checks.
- Existing oracle tests: `subagent-checkpoint-repository.test.ts:124`, `:135`, `:145`; `subagent-mailbox-projection.test.ts:10`; `run-event-query.test.ts:29`.
