import base from '/tmp/napier-host-accounting-vitest-v6.config.mts';
export default {...base,root:'/tmp/napier-g07-mailbox-baseline-20261030',test:{...base.test,include:['baseline.test.ts'],maxWorkers:1,reporters:['default','json'],outputFile:{json:'/tmp/napier-g07-mailbox-baseline-20261030/result-v2.json'}}};
