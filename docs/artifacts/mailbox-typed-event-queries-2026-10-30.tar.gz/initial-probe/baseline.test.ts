import { mkdir,writeFile } from 'node:fs/promises';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { it,expect,vi } from 'vitest';
import { accountingFixture } from '/Users/champ/orca/Napier/packages/runtime/test/model-accounting-fixture.ts';
import { LocalStore } from '/Users/champ/orca/Napier/packages/runtime/src/store.ts';
import { SqliteLedger } from '/Users/champ/orca/Napier/packages/runtime/src/sqlite-ledger.ts';
import { issueModelUndispatchedDriverProof } from '/Users/champ/orca/Napier/packages/runtime/src/model-call-attribution.ts';
import { canonicalJson,sha256 } from '/Users/champ/orca/Napier/packages/runtime/src/ed25519.ts';
import { applyThreadSummaryEvent,replayThreadSummaryTails } from '/Users/champ/orca/Napier/packages/runtime/src/store-thread-summary-projection.ts';
import { resolveRegisteredEventInput } from '/Users/champ/orca/Napier/packages/runtime/src/run-event-registry.ts';
import { InProcessSubagentProvider } from '/Users/champ/orca/Napier/packages/runtime/src/in-process-subagent-provider.ts';
import { continuationMailbox } from '/Users/champ/orca/Napier/packages/runtime/src/subagent-continuation-mailbox.ts';
import { projectSubagentMailbox } from '/Users/champ/orca/Napier/packages/runtime/src/subagent-mailbox-projection.ts';

const root='/tmp/napier-g07-mailbox-baseline-20261030';
it('measures native mailbox scans without any provider dispatch',async()=>{
 vi.stubGlobal('fetch',()=>{throw new Error('External calls forbidden');});
 const f=await accountingFixture(),child=await f.child();
 await f.store.modelAccountingRepository.closeUndispatchedChildInvocation(issueModelUndispatchedDriverProof(child.authority),'mailbox_baseline_no_model');
 function message(id:string,text:string){const body={kind:'napier.subagent-message',schemaVersion:1,id,taskId:child.task.id,messageKind:'steering',text,createdAt:new Date().toISOString()};return {...body,contentSha256:sha256(canonicalJson(body))};}
 const messages=[message('submsg_baseline0001','Constraint A'),message('submsg_baseline0002','Constraint B')];
 for(const message of messages) await f.store.acceptSubagentMessage({taskId:child.task.id,executionId:child.task.executionId!,message:message as any});
 await f.store.appendEvent({threadId:f.thread.id,runId:f.parent.run.id,type:'subagent.message.delivered',category:'subagent',payload:{taskId:child.task.id,executionId:child.task.executionId!,messageId:messages[1]!.id,messageKind:'steering',contentSha256:messages[1]!.contentSha256}});
 const templateEvents=(await Promise.all(f.store.listThreads().map(t=>f.store.listEvents(t.id)))).flat();
 const snapshot=(f.store as any).requireLedger().readSnapshot();const original=JSON.parse(snapshot.stateJson);
 replayThreadSummaryTails({threads:original.threads,expectedEventCount:snapshot.revision-snapshot.snapshotRevision,listEvents:(threadId:string,afterSeq:number)=>templateEvents.filter(e=>e.threadId===threadId&&e.seq>afterSeq)});
 await f.store.shutdown();f.source.close();
 const results:any[]=[];
 try {
 for(const count of [100,10_000,100_000]){
  const state=structuredClone(original),events=structuredClone(templateEvents),thread=state.threads.find((t:any)=>t.id===f.thread.id);
  const seq=thread.eventCount,epoch=Date.parse(thread.updatedAt);
  for(let n=0;n<count;n++){
   const checked=resolveRegisteredEventInput({threadId:f.thread.id,runId:f.parent.run.id,type:'model.text.delta',category:'model',visibility:'hidden',payload:{delta:'x'.repeat(128),deltaBytes:128,chunkCount:1}});
   const event={id:`event_mailbox_${count}_${n}`,threadId:f.thread.id,runId:f.parent.run.id,seq:seq+n+1,type:checked.type,category:checked.category,visibility:checked.visibility,createdAt:new Date(epoch+n+1).toISOString(),payload:checked.payload,schemaVersion:checked.schemaVersion};
   applyThreadSummaryEvent(thread,event as any);events.push(event as any);
  }
  const dataRoot=path.join(root,`seed-v2-${count}`);await mkdir(dataRoot,{recursive:true});const seed=new SqliteLedger(path.join(dataRoot,'ledger.sqlite'));seed.initialize();seed.bootstrap(JSON.stringify(state),events);seed.close();
  const store=new LocalStore({dataRoot,workspaceRoot:f.options.workspaceRoot});await store.initialize();
  try{
   expect((await store.listEvents(f.thread.id)).length).toBe(events.filter(e=>e.threadId===f.thread.id).length);
   const host=store as any,ledger=host.requireLedger(),native=ledger.listRunEvents.bind(ledger),all=store.listEvents.bind(store);
   let traces:any[]=[];
   vi.spyOn(ledger,'listRunEvents').mockImplementation((...args:any[])=>{const started=performance.now();const value=native(...args);traces.push({api:'ledger.listRunEvents',runId:args[0],afterSeq:args[1]??0,types:args[2]??null,rows:value.length,ms:performance.now()-started});return value;});
   vi.spyOn(store,'listEvents').mockImplementation(async(...args:any[])=>{const started=performance.now();const value=await all(...args);traces.push({api:'store.listEvents',threadId:args[0],rows:value.length,ms:performance.now()-started});return value;});
   const provider=new InProcessSubagentProvider({store,profile:f.profile,run:f.parent.run} as any);
   const handle={kind:'napier.subagent-handle',schemaVersion:1,providerId:'in_process',taskId:child.task.id,executionId:child.task.executionId!} as const;
   async function measure(name:string,iteration:number,action:()=>Promise<any>|any){traces=[];const cpu=process.cpuUsage(),started=performance.now();const output=await action();const wallMs=performance.now()-started,used=process.cpuUsage(cpu);const result={noiseEvents:count,name,iteration,wallMs,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000,rss:process.memoryUsage().rss,rows:traces.reduce((sum,t)=>sum+t.rows,0),traces,outputSha256:sha256(canonicalJson(output))};results.push(result);await writeFile(path.join(root,'measurements-v2.json'),JSON.stringify(results,null,2)+'\n');return output;}
   for(let i=0;i<3;i++){
    const prepared=await measure('prepare_checkpoint',i,()=>store.prepareSubagentChildCheckpoint(child.fence));expect(prepared.mailbox.accepted).toHaveLength(2);
    const duplicate=await measure('accept_duplicate',i,()=>store.acceptSubagentMessage({taskId:child.task.id,executionId:child.task.executionId!,message:messages[0] as any}));expect(duplicate.appended).toBe(false);
    const view=await measure('inspect',i,()=>provider.inspect(handle));expect(view.mailbox).toMatchObject({acceptedCount:2,deliveredCount:1,consumedCount:0});
    const task=store.listSubagentTasks(f.thread.id).find(t=>t.id===child.task.id)!,run=store.listRuns(f.thread.id).find(r=>r.id===task.childRunId)!;
    const replay=continuationMailbox(host,run,task);
    const typedHost={state:host.state,requireLedger:()=>({listRunEvents:(id:string)=>ledger.listRunEvents(id,0,['subagent.message.accepted'])})};
    const typed=await measure('typed_mailbox_feasibility_only',i,()=>{const result=continuationMailbox(typedHost as any,run,task);return {accepted:result.accepted,messages:[...result.messages]};});
    expect(canonicalJson({accepted:typed.accepted,messages:typed.messages})).toBe(canonicalJson({accepted:replay.accepted,messages:[...replay.messages]}));
    const typedEvents=await measure('typed_inspect_feasibility_only',i,async()=>{const started=performance.now();const value=await store.listEventsRange(f.thread.id,1,Number.MAX_SAFE_INTEGER,['subagent.message.accepted','subagent.message.delivered']);traces.push({api:'store.listEventsRange',threadId:f.thread.id,types:['subagent.message.accepted','subagent.message.delivered'],rows:value.length,ms:performance.now()-started});return value;});
    expect(projectSubagentMailbox(task,store.listSubagentTasks(f.thread.id),typedEvents)).toEqual(view.mailbox);
   }
   await writeFile(path.join(root,`seed-v2-${count}-receipt.json`),JSON.stringify({noiseEvents:count,eventCount:events.length,parentRows:events.filter(e=>e.runId===f.parent.run.id).length,childRows:events.filter(e=>e.runId===child.child.run.id).length,acceptedMessages:2,deliveredMessages:1,providerDispatches:0,fullReplayEquivalent:true},null,2)+'\n');
  }finally{vi.restoreAllMocks();await store.shutdown();}
 }
 }finally{vi.unstubAllGlobals();}
},120_000);
