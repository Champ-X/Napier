import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { fauxAssistantMessage, fauxToolCall } from "@earendil-works/pi-ai";
import { writeFile } from "node:fs/promises";
import { createModelSessionFixture, cleanupModelSessionFixtures } from "/Users/champ/orca/Napier/packages/runtime/test/subagent-model-session-fixture.ts";
import { continuationRunnerFixture, cleanupContinuationRunnerFixtures } from "/Users/champ/orca/Napier/packages/runtime/test/subagent-continuation-runner-fixture.ts";
import { processReadyAgentRuntime } from "/Users/champ/orca/Napier/packages/runtime/test/process-run-readiness-test-fixture.ts";
import { ComposableAgentModelCallPipeline } from "/Users/champ/orca/Napier/packages/runtime/src/kernel-model-call-pipeline.ts";
import { installBuiltinModelCallExtensions } from "/Users/champ/orca/Napier/packages/runtime/src/builtin-model-call-extensions.ts";

const reports: unknown[] = [];
beforeEach(() => vi.stubGlobal("fetch", vi.fn(() => { throw new Error("External requests forbidden"); })));
afterEach(async () => { vi.unstubAllGlobals(); await cleanupModelSessionFixtures(); await cleanupContinuationRunnerFixtures(); await writeFile("/tmp/napier-g03-parity-probe-20261030/results.json", JSON.stringify(reports, null, 2)); });
function instrument(runtime: any) {
  const hooks: Array<{ phase: string; run: string; source: string }> = []; let measures = 0;
  runtime.tokenMeters.register({ id: "test.parity-custom-meter", supports: () => true,
    measure(input: any) { measures++; return { estimatedTokens: input.conservativeFallbackTokens, method: "parity-counterexample-v1" }; } });
  const pipeline = new ComposableAgentModelCallPipeline(); installBuiltinModelCallExtensions(pipeline, runtime);
  pipeline.use({ id: "test.parity-extension",
    prepare(call) { hooks.push({ phase: "prepare", run: call.run.id, source: call.run.source }); return { context: { ...call.context,
      messages: [...call.context.messages, { role: "user", content: "G03_PREPARE_SENTINEL", timestamp: 1 }] } }; },
    finalize(call) { hooks.push({ phase: "finalize", run: call.run.id, source: call.run.source }); return { context: { ...call.context,
      messages: [...call.context.messages, { role: "user", content: "G03_FINALIZE_SENTINEL", timestamp: 1 }] } }; },
    around(call, next) { hooks.push({ phase: "around", run: call.run.id, source: call.run.source }); return next(); } });
  runtime.attachKernelModelCallPipeline(pipeline);
  return { hooks, measureCount: () => measures };
}
async function eventSummary(store: any, runId: string) {
  const events = await store.listRunEvents(runId); const types: Record<string, number> = {};
  for (const event of events) if (/context|prompt|harness/u.test(event.type)) types[event.type] = (types[event.type] ?? 0) + 1;
  return { types, meterProviderIds: [...new Set(events.flatMap((event: any) => typeof event.payload?.meterProviderId === "string" ? [event.payload.meterProviderId] : []))] };
}
function sampled(context: unknown, state: ReturnType<typeof instrument>) {
  return { prepareMarker: JSON.stringify(context).includes("G03_PREPARE_SENTINEL"),
    finalizeMarker: JSON.stringify(context).includes("G03_FINALIZE_SENTINEL"),
    hooks: state.hooks.length, measures: state.measureCount() };
}
it("observes the current first-launch child bypass under a main runtime pipeline", async () => {
  const f = await createModelSessionFixture();
  await f.store.updateAgent(f.run.agentId, { enabledSubagents: ["researcher"], enabledTools: ["list_files"], toolPolicy: "observe" });
  const thread = await f.store.createThread({ title: "Parity counterexample", agentId: f.run.agentId });
  const runtime = processReadyAgentRuntime(f.store, f.registry); const state = instrument(runtime); const samples: any[] = [];
  f.faux.setResponses([
    (context) => { samples.push({ owner: "parent-before", ...sampled(context, state) }); return fauxAssistantMessage(fauxToolCall("delegate_task", {
      role: "researcher", description: "Bounded child", task: "Return a summary as JSON." }), { stopReason: "toolUse" }); },
    (context) => { samples.push({ owner: "child", ...sampled(context, state) }); return fauxAssistantMessage('{"summary":"done","items":[],"unknowns":[]}'); },
    (context) => { samples.push({ owner: "parent-after", ...sampled(context, state) }); return fauxAssistantMessage("Done."); },
    fauxAssistantMessage('{"facts":[]}') ]);
  const parent = await runtime.runPrompt({ threadId: thread.id, text: "Delegate a small task.", model: { provider: f.faux.provider.id, id: "faux-1" } });
  const tasks = f.store.listSubagentTasks(thread.id, parent.id);
  expect(parent.status, parent.error).toBe("completed"); expect(tasks).toHaveLength(1); expect(tasks[0]!.status).toBe("completed");
  expect(samples[0]).toMatchObject({ prepareMarker: true, finalizeMarker: true, hooks: 3 }); expect(samples[0].measures).toBeGreaterThan(0);
  expect(samples[1]).toMatchObject({ prepareMarker: false, finalizeMarker: false, hooks: 3, measures: samples[0].measures });
  expect(samples[2]).toMatchObject({ prepareMarker: true, finalizeMarker: true, hooks: 6 });
  expect(new Set(state.hooks.map(hook => hook.run))).toEqual(new Set([parent.id]));
  const childRun = f.store.listRuns(thread.id).find(run => run.id === tasks[0]!.childRunId)!;
  expect(childRun).toMatchObject({ source: "subagent", status: "completed" }); expect(state.hooks.every(hook => hook.source !== "subagent")).toBe(true);
  reports.push({ case: "first_launch", parentRunId: parent.id, childRunId: childRun.id, childSource: childRun.source, childStatus: childRun.status, samples, hooks: state.hooks,
    parentEvents: await eventSummary(f.store, parent.id), childEvents: await eventSummary(f.store, childRun.id) });
});
it("observes the current continued child bypass before the recovered parent's first call", async () => {
  const f = await continuationRunnerFixture(); const interrupted = await f.interrupt();
  const runtime = processReadyAgentRuntime(interrupted.store, f.registry); const state = instrument(runtime); const samples: any[] = [];
  f.faux.setResponses([
    (context) => { samples.push({ owner: "continued-child", ...sampled(context, state) }); return fauxAssistantMessage('{"answer":"continued"}'); },
    (context) => { samples.push({ owner: "recovered-parent", ...sampled(context, state) }); return fauxAssistantMessage("Child collected."); },
    fauxAssistantMessage('{"facts":[]}') ]);
  const parent = await runtime.resumeInterruptedRun({ threadId: f.thread.id, runId: f.parent.run.id });
  const successor = interrupted.store.listSubagentTasks(f.thread.id).find(task => task.continuedFromTaskId === f.task.id)!;
  expect(parent.status, parent.error).toBe("completed"); expect(successor.status).toBe("completed");
  expect(samples[0]).toMatchObject({ prepareMarker: false, finalizeMarker: false, hooks: 0, measures: 0 });
  expect(samples[1]).toMatchObject({ prepareMarker: true, finalizeMarker: true, hooks: 3 }); expect(samples[1].measures).toBeGreaterThan(0);
  expect(new Set(state.hooks.map(hook => hook.run))).toEqual(new Set([parent.id]));
  const childRun = interrupted.store.listRuns(f.thread.id).find(run => run.id === successor.childRunId)!;
  expect(childRun).toMatchObject({ source: "subagent", status: "completed" }); expect(state.hooks.every(hook => hook.source !== "subagent")).toBe(true);
  reports.push({ case: "continuation", parentRunId: parent.id, childRunId: childRun.id, childSource: childRun.source, childStatus: childRun.status, samples, hooks: state.hooks,
    parentEvents: await eventSummary(interrupted.store, parent.id), childEvents: await eventSummary(interrupted.store, childRun.id) });
});
