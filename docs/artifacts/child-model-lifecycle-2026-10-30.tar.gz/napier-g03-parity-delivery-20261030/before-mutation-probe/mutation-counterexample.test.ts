import { writeFile } from "node:fs/promises";
import path from "node:path";
import { contentText, fauxAssistantMessage, fauxToolCall, type Context } from "@earendil-works/pi-ai";
import type { RunRecord } from "@napier/contracts";
import { Type } from "typebox";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { AgentRuntime } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/agent-runtime.js";
import { installBuiltinModelCallExtensions } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/builtin-model-call-extensions.js";
import { validateCompiledPromptPackageReceiptV3 } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/compiled-prompt-package.js";
import { ComposableAgentModelCallPipeline } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/kernel-model-call-pipeline.js";
import { subagentRoleInstructions, subagentRoleInstructionsForSchema } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/subagent-role-instructions.js";
import { readSubagentWorkingSetForRestore } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/src/subagent-working-set-capsule.js";
import { processReadyAgentRuntime } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/test/process-run-readiness-test-fixture.js";
import { createModelSessionFixture, cleanupModelSessionFixtures } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/test/subagent-model-session-fixture.js";
import { continuationRunnerFixture, continuationOutputSchema, cleanupContinuationRunnerFixtures } from "/tmp/napier-g03-compiler-parity-20261030/packages/runtime/test/subagent-continuation-runner-fixture.js";

const PREPARE_MARKER = "G03_PARITY_PREPARE_SENTINEL";
const FINALIZE_MARKER = "G03_PARITY_FINALIZE_SENTINEL";
const METER_ID = "test.parity-custom-meter";
const outcome = '{"summary":"done","items":[],"unknowns":[]}';

beforeEach(() => vi.stubGlobal("fetch", vi.fn(() => { throw new Error("External model requests forbidden"); })));
afterEach(async () => {
  vi.unstubAllGlobals();
  await cleanupModelSessionFixtures();
  await cleanupContinuationRunnerFixtures();
});

function instrument(runtime: AgentRuntime) {
  const hooks: Array<{ phase: string; runId: string; source: RunRecord["source"] }> = [];
  let measurements = 0;
  runtime.tokenMeters.register({ id: METER_ID, supports: () => true, measure(input) {
    measurements += 1;
    return { estimatedTokens: input.conservativeFallbackTokens, method: "parity-counterexample-v1" };
  } });
  const pipeline = new ComposableAgentModelCallPipeline();
  installBuiltinModelCallExtensions(pipeline, runtime);
  pipeline.use({ id: "test.parity-extension",
    prepare(call) {
      hooks.push({ phase: "prepare", runId: call.run.id, source: call.run.source });
      return { context: { ...call.context, messages: [...call.context.messages,
        { role: "user", content: PREPARE_MARKER, timestamp: 1 }] } };
    },
    finalize(call) {
      hooks.push({ phase: "finalize", runId: call.run.id, source: call.run.source });
      return { context: { ...call.context, messages: [...call.context.messages,
        { role: "user", content: FINALIZE_MARKER, timestamp: 1 }] } };
    },
    around(call, next) {
      hooks.push({ phase: "around", runId: call.run.id, source: call.run.source });
      return next();
    },
  });
  runtime.attachKernelModelCallPipeline(pipeline);
  return { pipeline, hooks, measurements: () => measurements };
}

async function assertChildEvidence(runtime: AgentRuntime, child: RunRecord, context: Context, rolePrompt: string, parentRunId: string) {
  expect(child).toMatchObject({ source: "subagent", status: "completed" });
  expect(context.systemPrompt).toContain(rolePrompt);
  expect(JSON.stringify(context.messages)).toContain(PREPARE_MARKER);
  expect(JSON.stringify(context.messages)).toContain(FINALIZE_MARKER);
  const events = await runtime.store.listRunEvents(child.id);
  expect(events.map(event => event.type)).toEqual(expect.arrayContaining([
    "model.harness.resolved", "context.projected", "context.prompt_package",
  ]));
  expect(events.filter(event => event.type === "model.context.token_pressure").map(event => event.payload))
    .toEqual(expect.arrayContaining([expect.objectContaining({ meterProviderId: METER_ID })]));
  const packages = events.filter(event => event.type === "context.prompt_package");
  expect(packages).toHaveLength(1);
  const compiled = validateCompiledPromptPackageReceiptV3(packages[0]!.payload);
  const envelope = events.find(event => event.type === "context.model_envelope")!;
  expect(compiled).toMatchObject({ purpose: "agent_turn", systemPromptSha256: envelope.payload.systemPromptSha256,
    effectiveCapabilities: { toolDefinitionSetSha256: envelope.payload.toolDefinitionSetSha256 } });
  const receipts = (await runtime.store.listRunEvents(parentRunId)).filter(event => event.type === "subagent.model.invocation")
    .map(event => event.payload as unknown as { owner: { childRunId: string }; phase: string; contextEnvelopeSha256: string;
      captures: Array<{ kind: string; payload: { capsuleSha256?: string } }> })
    .filter(receipt => receipt.owner.childRunId === child.id);
  expect(receipts).toHaveLength(1);
  expect(receipts[0]).toMatchObject({ phase: "subagent_turn", contextEnvelopeSha256: envelope.payload.contentSha256 });
  const capture = receipts[0]!.captures.find(item => item.kind === "invocation")!;
  const invocation = await runtime.modelInvocationCapsules.read(capture.payload.capsuleSha256!);
  expect(invocation.sourceRunId).toBe(child.id);
  expect(invocation.context).toEqual(context);
  const restored = await readSubagentWorkingSetForRestore(runtime.store.dataRoot, child.subagent!.checkpoint!.capsuleSha256);
  expect(restored.capsule.systemPrompt).toBe(rolePrompt);
  expect(restored.capsule.tools.map(tool => tool.name).sort()).toEqual((context.tools ?? []).map(tool => tool.name).sort());
  expect(JSON.stringify(restored.capsule.messages)).not.toContain(PREPARE_MARKER);
  expect(JSON.stringify(restored.capsule.messages)).not.toContain(FINALIZE_MARKER);
  expect((context.tools ?? []).map(tool => tool.name)).not.toContain("delegate_task");
  return restored.capsule;
}

async function delegationFixture() {
  const fixture = await createModelSessionFixture();
  await fixture.store.updateAgent(fixture.run.agentId, { enabledSubagents: ["researcher"], enabledTools: ["list_files"], toolPolicy: "observe" });
  const thread = await fixture.store.createThread({ title: "Child pipeline parity", agentId: fixture.run.agentId });
  const runtime = processReadyAgentRuntime(fixture.store, fixture.registry);
  const observation = instrument(runtime);
  const delegate = fauxAssistantMessage(fauxToolCall("delegate_task", {
    role: "researcher", description: "Bounded parity task", task: "Return a summary as JSON.",
  }), { stopReason: "toolUse" });
  return { ...fixture, thread, runtime, observation, delegate,
    runPrompt: (signal?: AbortSignal) => runtime.runPrompt({ threadId: thread.id, text: "Delegate a small task.",
      model: { provider: fixture.faux.provider.id, id: "faux-1" }, ...(signal ? { signal } : {}) }) };
}

describe("main and child compiler and model-call extension parity", () => {
  it("uses the attached pipeline and meter for a first-launch child while keeping its raw role, tools and checkpoint", async () => {
    const f = await delegationFixture();
    let beforeChildMeasurements = 0;
    let childMeasurements = 0;
    let childContext: Context | undefined;
    f.faux.setResponses([
      () => { beforeChildMeasurements = f.observation.measurements(); return f.delegate; },
      context => { childContext = structuredClone(context); childMeasurements = f.observation.measurements(); return fauxAssistantMessage(outcome); },
      fauxAssistantMessage("Collected the delegated result."), fauxAssistantMessage('{"facts":[]}'),
    ]);
    const parent = await f.runPrompt();
    expect(parent.status, parent.error).toBe("completed");
    const tasks = f.store.listSubagentTasks(f.thread.id, parent.id);
    expect(tasks).toHaveLength(1);
    expect(tasks[0]!.status, tasks[0]!.error).toBe("completed");
    const child = f.store.listRuns(f.thread.id).find(run => run.id === tasks[0]!.childRunId)!;
    expect(f.observation.hooks.filter(hook => hook.runId === child.id).map(hook => hook.phase)).toEqual(["prepare", "finalize", "around"]);
    expect(f.observation.hooks.filter(hook => hook.runId === child.id).every(hook => hook.source === "subagent")).toBe(true);
    expect(childMeasurements).toBeGreaterThan(beforeChildMeasurements);
    const raw = await assertChildEvidence(f.runtime, child, childContext!, subagentRoleInstructions("researcher"), parent.id);
    expect(raw.messages[0]).toMatchObject({ role: "user" });
    expect(contentText(raw.messages[0]!.content)).toBe(tasks[0]!.prompt);
    expect(raw.tools.map(tool => tool.name)).toEqual(["list_files"]);
  });

  it("uses the same pipeline for a continued child while preserving inherited read evidence without replaying its tool", async () => {
    const f = await continuationRunnerFixture({ readFile: true });
    await writeFile(path.join(f.workspaceRoot, "source.txt"), "inherited parity source");
    await f.assistant(fauxAssistantMessage(fauxToolCall("read_file", { path: "source.txt" }, { id: "inherited-read" }), { stopReason: "toolUse" }));
    const interrupted = await f.interrupt();
    const runtime = processReadyAgentRuntime(interrupted.store, f.registry);
    const observation = instrument(runtime);
    let childContext: Context | undefined;
    let childMeasurements = 0;
    f.faux.setResponses([
      context => { childContext = structuredClone(context); childMeasurements = observation.measurements(); return fauxAssistantMessage('{"answer":"continued"}'); },
      fauxAssistantMessage("Child collected."), fauxAssistantMessage('{"facts":[]}'),
    ]);
    const parent = await runtime.resumeInterruptedRun({ threadId: f.thread.id, runId: f.parent.run.id });
    expect(parent.status, parent.error).toBe("completed");
    const successor = interrupted.store.listSubagentTasks(f.thread.id).find(task => task.continuedFromTaskId === f.task.id)!;
    expect(successor.status, successor.error).toBe("completed");
    const child = interrupted.store.listRuns(f.thread.id).find(run => run.id === successor.childRunId)!;
    expect(observation.hooks.filter(hook => hook.runId === child.id).map(hook => hook.phase)).toEqual(["prepare", "finalize", "around"]);
    expect(childMeasurements).toBeGreaterThan(0);
    const raw = await assertChildEvidence(runtime, child, childContext!, subagentRoleInstructionsForSchema("researcher", continuationOutputSchema), parent.id);
    expect(raw.messages.slice(0, f.messages.length)).toEqual(f.messages);
    expect(JSON.stringify(childContext!.messages)).toContain("inherited parity source");
    expect((await interrupted.store.listRunEvents(child.id)).filter(event => event.type === "tool.started")).toEqual([]);
    expect(successor.turnCount).toBe(1);
  });

  it("observes an in-place child prepare mutation bypassing the existing policy guard", async () => {
    const f = await delegationFixture();
    let childPhysicalCalls = 0;
    let excludedChildToolAttempted = false; let receivedTools: string[] = [];
    f.observation.pipeline.use({ id: "test.child-excluded-tool", prepare(call) {
      if (call.run.source !== "subagent") return;
      excludedChildToolAttempted = true;
      call.context.tools!.push({ name: "forbidden_write", description: "Not granted to this child", parameters: Type.Object({}) });
    } });
    f.faux.setResponses([f.delegate, fauxAssistantMessage(outcome), fauxAssistantMessage('{"facts":[]}')]
      .map(response => context => {
        if (context.systemPrompt?.includes(subagentRoleInstructions("researcher"))) { childPhysicalCalls += 1; receivedTools = (context.tools ?? []).map(tool => tool.name); }
        return response;
      }));
    const parent = await f.runPrompt();
    const task = f.store.listSubagentTasks(f.thread.id, parent.id)[0]!;
    expect(task.status).toBe("failed"); expect(task.error).toContain("checkpoint tool definitions");
    await writeFile("/tmp/napier-g03-parity-mutation-probe-20261030/results.json", JSON.stringify({ childStatus: task.status, childRunId: task.childRunId, childPhysicalCalls, receivedTools, hooks: f.observation.hooks }, null, 2));
    expect(excludedChildToolAttempted).toBe(true);
    expect(childPhysicalCalls).toBe(1); expect(receivedTools).toContain("forbidden_write");
    expect(f.observation.hooks.filter(hook => hook.runId === task.childRunId).map(hook => hook.phase)).toContain("around");
    const events = await f.store.listRunEvents(task.childRunId!);
    expect(events.filter(event => event.type === "subagent.child.invocation_reserved")).toHaveLength(1); expect(events.filter(event => event.type === "model.response")).toHaveLength(1);
  });

  it("keeps parent cancellation effective while a child finalizer is awaiting completion", async () => {
    const f = await delegationFixture();
    const abort = new AbortController();
    let childFinalized = false;
    f.observation.pipeline.use({ id: "test.child-finalize-cancel", async finalize(call) {
      if (call.run.source !== "subagent") return;
      await Promise.resolve();
      childFinalized = true;
      abort.abort(new Error("Cancelled in child finalizer"));
    } });
    f.faux.setResponses([f.delegate, fauxAssistantMessage(outcome)]);
    const parent = await f.runPrompt(abort.signal);
    expect(childFinalized).toBe(true);
    expect(parent.status).toBe("cancelled");
    const task = f.store.listSubagentTasks(f.thread.id, parent.id)[0]!;
    expect(task.status).toBe("cancelled");
    expect(f.faux.state.callCount).toBe(1);
    expect((await f.store.listRunEvents(task.childRunId!)).some(event => event.type === "run.completed")).toBe(false);
  });
});
