export default { root: "/tmp/napier-g03-parity-mutation-probe-20261030", test: { include: ["*.test.ts"], maxWorkers: 1, testTimeout: 30000 } };
