#!/usr/bin/env python3
"""Verify retained artifacts, exact case overlap, and optional checkout source hashes."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkout', type=Path, help='Optional checkout to compare with sealed source hashes')
parser.add_argument('--integrated', action='store_true', help='Use root integrated v3 source hashes for --checkout')
args = parser.parse_args()
root = Path(__file__).resolve().parent

def read(name):
    return json.loads((root / name).read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_file(path, size, expected):
    if not path.is_file() or path.stat().st_size != size or digest(path) != expected:
        raise SystemExit(f'Artifact mismatch: {path}')

manifest = read('delivery-manifest.json')
for item in manifest['artifacts']:
    check_file(root / item['path'], item['bytes'], item['sha256'])
source = read('candidate-source-manifest.json')
if digest(root / 'candidate.patch') != source['patchSha256'] or source['patchSha256'] != manifest['patchSha256']:
    raise SystemExit('Candidate patch hash mismatch')

owned = {item['path'] for item in source['files'] if item['path'].endswith('.test.ts')}
def cases(name):
    report = read(name)
    result = set()
    total = 0
    for suite in report['testResults']:
        relative = 'packages/runtime/test/' + Path(suite['name']).name
        for case in suite['assertionResults']:
            total += 1
            if case['status'] != 'passed':
                raise SystemExit(f'Non-passing case in {name}: {case["fullName"]}')
            result.add((relative, tuple(case['ancestorTitles']), case['title'], case['fullName'], case['status']))
    if len(result) != total:
        raise SystemExit(f'Duplicate case identity in {name}')
    return result

original = cases('final-tests.json')
new = cases('v3-new-tests.json')
root55 = cases('root-integration-v2/tests.json')
root20 = cases('root-integration-v3/tests.json')
assert len(original) == 225 and len(new) == 38 and len(root55) == 55 and len(root20) == 20
assert {case for case in original if case[0] in owned} == new
assert {case for case in root55 if case[0] in owned} == new
assert root20 == {case for case in new if case[0] != 'packages/runtime/test/model-call-extension-mutation-guards.test.ts'}

v2 = {item['path']: item['sha256'] for item in read('candidate.v2-source-manifest.json')['files']}
changed = [item['path'] for item in source['files'] if item['sha256'] != v2[item['path']]]
assert len(changed) == 5 and set(changed).issubset(owned)
assert len([item for item in source['files'] if '/src/' in item['path']]) == 28
if args.checkout:
    expected = read('root-integration-v3/regression.json')['sourceManifest']['files'] if args.integrated else {
        item['path']: item['sha256'] for item in source['files']}
    for relative, expected_hash in expected.items():
        path = args.checkout / relative
        if not path.is_file() or digest(path) != expected_hash:
            raise SystemExit(f'Checkout mismatch: {path}')
print(json.dumps({'artifactsVerified': len(manifest['artifacts']), 'caseIdentityChecks': 'passed',
                  'evidenceCounts': {'original': 225, 'ownerV3': 38, 'rootV2': 55, 'rootV3': 20},
                  'countsAreOverlappingNotAdditive': True, 'productionFilesUnchangedFromV2': 28,
                  'checkoutVerified': str(args.checkout) if args.checkout else None}, indent=2))
