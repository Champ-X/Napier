import type { JsonObject, RunEvent, RunRecord, SubagentTask } from "@napier/contracts";
import { expect, it } from "vitest";
import { canonicalJson, sha256 } from "../src/ed25519.js";
import { createModelContextEnvelopeReceipt } from "../src/model-context-envelope.js";
import { assertChildCheckpointTranscript } from "../src/subagent-checkpoint-transcript.js";
import { bindChildInvocationCapture } from "../src/subagent-child-invocation-capture.js";
import type { SubagentWorkingSetBinding } from "../src/subagent-working-set-types.js";

const tools = ["read_file", "list_files"].map(name => ({ name, description: name, parameters: { type: "object", properties: {} } }));
const full = createModelContextEnvelopeReceipt({ turnIndex: 0, systemPrompt: "role", tools, messages: [] });
const task = { prompt: "bounded task", role: "researcher" } as SubagentTask;
const run = { configuration: { systemPromptSha256: full.systemPromptSha256, enabledTools: tools.map(tool => tool.name) } } as RunRecord;
const binding = { systemPromptSha256: full.systemPromptSha256, toolDefinitionSetSha256: full.toolDefinitionSetSha256,
  toolNames: tools.map(tool => tool.name), tools,
  transcript: { users: [{ messageIndex: 0, contentSha256: sha256(canonicalJson(task.prompt)) }], assistantMessageSha256s: ["assistant"], toolResults: [] },
  mailbox: { entries: [] } } as unknown as SubagentWorkingSetBinding;

function response(activeTools = tools.slice(0, 1)) {
  const envelope = createModelContextEnvelopeReceipt({ turnIndex: 0, systemPrompt: "compiled role", tools: activeTools, messages: [] });
  const captured = bindChildInvocationCapture({ payload: {}, capture: { envelope, toolNames: activeTools.map(tool => tool.name) } }, 1);
  return { type: "model.response", payload: { ...captured.payload, subagentPhase: "subagent_turn", stopReason: "stop", responseSha256: "assistant" } } as RunEvent;
}

it("allows an exact authorized subset while retaining the full raw checkpoint tool definitions", () => {
  expect(() => assertChildCheckpointTranscript(binding, run, task, [response()], [])).not.toThrow();
  expect(binding.tools).toHaveLength(2);
});

it.each(["definition", "missing_names", "extra_name"])("rejects %s when proving a request-local tool subset", (kind) => {
  const event = response(kind === "definition" ? [{ ...tools[0]!, description: "Changed authority surface" }] : undefined);
  const payload = event.payload as JsonObject;
  if (kind === "missing_names") delete payload["modelContextToolNames"];
  if (kind === "extra_name") payload["modelContextToolNames"] = ["read_file", "forbidden_write"];
  expect(() => assertChildCheckpointTranscript(binding, run, task, [event], [])).toThrow("tool definitions differ");
});

it("rejects tool-name metadata that is not bound to the exact captured envelope", () => {
  const envelope = createModelContextEnvelopeReceipt({ turnIndex: 0, systemPrompt: "role", tools: tools.slice(0, 1), messages: [] });
  expect(() => bindChildInvocationCapture({ payload: {}, capture: { envelope, toolNames: ["forbidden_write"] } }, 1))
    .toThrow("tool names differ");
  expect(() => bindChildInvocationCapture({ payload: { modelContextToolNames: ["read_file"] }, capture: { envelope } }, 1))
    .toThrow("captured envelope binding");
});
