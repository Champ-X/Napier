import base from '/tmp/napier-host-accounting-vitest-v6.config.mts';
export default {...base,root:'/tmp/napier-g01-tool-output-counterexample-20261030',test:{...base.test,include:['counterexample.test.ts'],maxWorkers:1,reporters:['default','json'],outputFile:{json:'/tmp/napier-g01-tool-output-counterexample-20261030/result-v2.json'}}};
