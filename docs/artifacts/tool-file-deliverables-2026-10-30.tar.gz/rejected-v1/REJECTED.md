Rejected at root review: digest-only idempotency cannot distinguish actual A-B-A tool invocations from an old receipt retry. Do not apply this patch; retained as failed evidence.
