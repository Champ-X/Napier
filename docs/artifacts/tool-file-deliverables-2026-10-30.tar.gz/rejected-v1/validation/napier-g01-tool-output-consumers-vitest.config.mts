export default {
  root: '/tmp/napier-g01-tool-output-implementation-20261030',
  resolve: { alias: [
    { find: '@napier/contracts/task-narrative', replacement: '/tmp/napier-g01-tool-output-implementation-20261030/packages/contracts/src/task-narrative.ts' },
    { find: '@napier/contracts', replacement: '/tmp/napier-g01-tool-output-implementation-20261030/packages/contracts/src/index.ts' },
  ] },
  test: { include: ['apps/web/test/tool-file-deliverable-consumers.test.ts', 'apps/web/test/task-narrative-protocol.test.ts', 'apps/web/test/task-completion-summary.test.ts'], maxWorkers: 1, reporters: ['default', 'json'], outputFile: { json: '/tmp/napier-g01-tool-output-consumers-result.json' } },
};
