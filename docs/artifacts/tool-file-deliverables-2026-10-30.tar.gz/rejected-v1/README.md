# G01 verified tool-file delivery slice

Apply `candidate.patch` to base `49a91de9b8d3871ecf1c9e40761086598dc08595`; root owns integration and commits. The 22-file patch records verified tool files when no Run-bound Plan/matching artifact can be settled, then projects those receipts through full, warm, and reopened TaskNarrative reads. Browser outputs retain produced provenance; research verification records observed-file provenance. Neither accepts the whole objective.

`delivery-manifest.json` binds every changed file and the patch. `source/` contains exact candidate copies. `before/` preserves both the original cleanup-obscured probe and corrected assertion failures; `after-final/` contains the final native passing probe. Raw fixture data directories remain local at paths recorded in observations; no databases are included here.

Validation: 35 files / 328 tests, core TypeScript compilation, and Web TypeScript checking passed. Native counterexamples changed from two intended failures to two passes. Full, warm-cache, and reopened projections agree. Architecture still has seven baseline violations; public API still has four. Both sets and the complete public API observations match the isolated baseline. Early implementation/test failures are retained under `validation/`.

Web scope is only the shared-protocol acceptance gate and consumer tests. `web_fetch.save` still requires Plan authority before network/write. No protected user files, main index, main goal/docs, or shared package output were changed by this task. No external models/providers were invoked.

Coverage includes receipt deduplication, lost append acknowledgement, same-path versions, continuation retention, late older-Run ordering, child/foreign/terminal refusal, missing/drifted files, unsafe paths/symlinks/FIFOs/oversized files, formal declaration precedence, final-reference suppression, exact receipt/hash binding, and actual local research_source tool execution. The Browser case uses its production writer/registrar seam; it does not establish live-provider acceptance. File integrity/citation tokens do not establish semantic entailment or overall G01 completion.

Run `node replay-native-probe.mjs /path/to/isolated-checkout before|after /tmp/new-probe-directory` after installing dependencies and building isolated contracts/runtime. The `before` mode intentionally exits nonzero at the absent-deliverable assertion on the base checkout. The research report includes actual generated citation IDs, so report hashes vary between runs; each assertion checks its own exact bytes.
