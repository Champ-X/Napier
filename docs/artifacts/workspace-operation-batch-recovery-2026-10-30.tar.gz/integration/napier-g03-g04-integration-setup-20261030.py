from pathlib import Path
import json,hashlib,shutil,subprocess
w=Path('/Users/champ/orca/Napier');r=Path('/tmp/napier-g03-g04-integration-20261030').resolve();base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
a=json.load(open('/tmp/napier-g03-shared-allowance-frozen-20261030-v1/source-manifest.json'));b=json.load(open('/tmp/napier-g04-delivery-manifest-20261030.json'));g03={f['path']:f['sha256'] for f in a['files']};g04={p:x['sha256'] for p,x in b['paths'].items() if p.startswith(('packages/','apps/'))};assert not set(g03)&set(g04);files={**g03,**g04}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(w/p)==h for p,h in files.items())
subprocess.run(['git','worktree','add','--detach',str(r),base],cwd=w,check=True)
for p in files:shutil.copy2(w/p,r/p)
n=r/'node_modules';n.mkdir()
for p in (w/'node_modules').iterdir():
 if p.name!='@napier':(n/p.name).symlink_to(p,target_is_directory=p.is_dir())
(n/'@napier').mkdir()
for p in (w/'node_modules/@napier').iterdir():(n/'@napier'/p.name).symlink_to(r/p.resolve().relative_to(w),target_is_directory=True)
subprocess.run(['git','add','--',*files],cwd=r,check=True)
m={'base':base,'root':str(r),'tree':subprocess.check_output(['git','write-tree'],cwd=r,text=True).strip(),'files':files,'G03':g03,'G04':g04};Path('/tmp/napier-g03-g04-integration-source-20261030.json').write_text(json.dumps(m,indent=2)+'\n');print({'files':len(files),'base':base,'tree':m['tree']})
