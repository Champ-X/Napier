from pathlib import Path
import json,hashlib,subprocess
w=Path('/Users/champ/orca/Napier');m=json.load(open('/tmp/napier-g03-g04-integration-source-20261030.json'));d=json.load(open('/tmp/napier-g03-g04-integration-result-20261030/regression.json'));assert d['passed']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(w/p)==h for p,h in m['files'].items());protected=json.load(open('/tmp/napier-overlay-preserved-user-files-20261029.json'));assert all(sha(w/p)==h for p,h in protected.items());assert not set(protected)&set(m['files']);assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=w,text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==m['base']
commits=[]
for name,title in [('G03','fix(runtime): reserve in-flight model allowances across child runs'),('G04','fix(runtime): reconcile independent workspace operation batches')]:
 paths=sorted(m[name]);subprocess.run(['git','add','--',*paths],cwd=w,check=True);assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=w,text=True).splitlines()==paths;subprocess.run(['git','diff','--cached','--check'],cwd=w,check=True);tree=subprocess.check_output(['git','write-tree'],cwd=w,text=True).strip();subprocess.run(['git','commit','-m',title],cwd=w,check=True);commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();commits.append({'scope':name,'commit':commit,'tree':tree,'files':m[name]})
assert subprocess.check_output(['git','write-tree'],cwd=w,text=True).strip()==m['tree'];assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=w,text=True).strip()
Path('/tmp/napier-g03-g04-source-commits-20261030.json').write_text(json.dumps({'base':m['base'],'commits':commits,'integration':'/tmp/napier-g03-g04-integration-result-20261030/regression.json','finalTree':m['tree'],'push':False},indent=2)+'\n');print([{k:v for k,v in c.items() if k!='files'} for c in commits])
