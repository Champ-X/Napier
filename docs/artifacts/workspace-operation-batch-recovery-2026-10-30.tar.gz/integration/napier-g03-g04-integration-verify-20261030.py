from pathlib import Path
import json,subprocess,hashlib,datetime,concurrent.futures
r=Path('/private/tmp/napier-g03-g04-integration-20261030');out=Path('/tmp/napier-g03-g04-integration-result-20261030');out.mkdir();m=json.load(open('/tmp/napier-g03-g04-integration-source-20261030.json'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(folders):return {str(p.relative_to(r)):sha(p) for f in folders for p in sorted((r/f).rglob('*')) if p.is_file()}
def check(name,args,required=True):
 p=out/(name+'.log');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with p.open('w') as f:x=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 v={'name':name,'argv':args,'cwd':str(r),'exitCode':x.returncode,'required':required,'log':str(p),'sha256':sha(p),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};print({'name':name,'exit':x.returncode},flush=True);return v
sourceFolders=['packages/contracts/src','packages/runtime/src','packages/runtime/test','apps/server/src','apps/server/test','apps/web/src','apps/web/test'];before=manifest(sourceFolders)
checks=[check('full-compile',['node','node_modules/typescript/bin/tsc','-b','packages/runtime','apps/cli','apps/server','--force']),check('bundled-skills',['node','scripts/copy-bundled-skills.mjs']),check('sandbox-assets',['node','scripts/copy-sandbox-image.mjs'])]
if any(x['exitCode'] for x in checks): (out/'compile-failure.json').write_text(json.dumps(checks,indent=2)+'\n');raise SystemExit(1)
emitted=manifest(['packages/contracts/dist','packages/runtime/dist','apps/server/dist','apps/cli/dist'])
g03=['model-run-budget-allowance','model-accounting-repository','model-accounting-continuation','subagent-continuation-parent-budget','task-outcome-projection'];g04=['workspace-operation-batch-recovery','deferred-operation-reinspection']
jobs=[('g03-and-projection',['node','node_modules/vitest/vitest.mjs','run','--dir','packages/runtime/test',*[f'packages/runtime/test/{p}.test.ts' for p in g03],'--maxWorkers=2','--testTimeout=30000','--reporter=json','--outputFile='+str(out/'g03.json')],True),('g04-batch',['node','node_modules/vitest/vitest.mjs','run','--config','packages/runtime/test/workspace-file-move-vitest.config.ts',*[f'packages/runtime/test/{p}.test.ts' for p in g04],'--maxWorkers=2','--testTimeout=30000','--reporter=json','--outputFile='+str(out/'g04.json')],True),('web-types',['node','node_modules/typescript/bin/tsc','-p','apps/web/tsconfig.json','--noEmit'],True),('architecture',['node','scripts/check-architecture.mjs'],False),('public-api',['node','scripts/check-public-api.mjs'],False),('diff-check',['git','diff','--cached','--check'],True)]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:checks+=list(pool.map(lambda x:check(*x),jobs))
after=manifest(sourceFolders);afterEmit=manifest(['packages/contracts/dist','packages/runtime/dist','apps/server/dist','apps/cli/dist'])
for name,data in [('source-before',before),('source-after',after),('emitted-before',emitted),('emitted-after',afterEmit)]: (out/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
reports={}
for name in ['g03','g04']:
 p=out/(name+'.json');j=json.load(open(p));reports[name]={'path':str(p),'sha256':sha(p),'files':len(j['testResults']),'tests':j['numTotalTests'],'passed':j['numPassedTests'],'failed':j['numFailedTests'],'skipped':j['numPendingTests']}
d={'sourceManifest':m,'checks':checks,'reports':reports,'sourceCount':len(before),'emittedCount':len(emitted),'sourceStable':before==after,'emittedStable':emitted==afterEmit,'passed':before==after and emitted==afterEmit and all(x['exitCode']==0 for x in checks if x['required']),'scope':'G01 committed source + exact17 G03 allowance + exact15 G04 batch source. Full compile and focused interaction regressions; owner193 and133 suites remain independently recorded, not added again.'};(out/'regression.json').write_text(json.dumps(d,indent=2)+'\n');print({'passed':d['passed'],'reports':reports},flush=True)
