import assert from 'node:assert/strict';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';
import { LocalStore } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/store.ts';
import { acquireWorkspacePathLocks } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/workspace-write-lock.ts';
import { lockWorkspaceOperationChecks } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/workspace-operation-recovery-check.ts';
import { reconcileSettledWorkspaceOperations } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/workspace-operation-reconciliation.ts';
import { operationReconciliationCommitEvents } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/workspace-operation-recovery-scope.ts';
import { deferredOperationHint } from '/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/src/run-deferred-operation-recovery.ts';

const out='/tmp/napier-g04-independent-review-20261030';
const root=path.join(out,'fixture-v2');await mkdir(root,{recursive:true});
const checked:string[]=[];
const fixture='/private/tmp/napier-g04-batch-verify-20261030/packages/runtime/test/fixtures/workspace-operation-batch-crash.ts';
await assert.rejects(promisify(execFile)(process.execPath,['--import','tsx',fixture,root,'mixed','after-effect'],{
 cwd:'/private/tmp/napier-g04-batch-verify-20261030',env:process.env,timeout:20_000}),{code:73});
const db=new DatabaseSync(path.join(root,'data/ledger.sqlite'));
const snapshot=JSON.parse(String(db.prepare('SELECT state_json FROM workspace_state WHERE singleton=1').get()!.state_json));
const crash=JSON.parse(await readFile(path.join(root,'crash.json'),'utf8'));
const original=snapshot.runs.find((run:any)=>run.id===crash.runId);
const before=db.prepare('SELECT event_json FROM ledger_events WHERE run_id=? ORDER BY seq').all(original.id).map((row:any)=>JSON.parse(row.event_json));db.close();
const hint=deferredOperationHint(original,before);assert.ok(hint);
const invalidBefore=structuredClone(before);invalidBefore.find((e:any)=>e.type==='workspace.patch.prepared').payload={};
assert.equal(deferredOperationHint(original,invalidBefore),undefined);checked.push('deferred hint includes settled preparation validity; malformed retained participant supplies no scheduling hint');
const store=new LocalStore({workspaceRoot:path.join(root,'workspace'),dataRoot:path.join(root,'data')});await store.initialize(true);
try{
 const source=store.listRuns(original.threadId).find((r:any)=>r.id===original.id)!;assert.equal(source.status,'interrupted');
 const events=await store.listRunEvents(original.id);const marker=events.find((e:any)=>e.type==='tool.operation.effect_indeterminate')!;
 const prior=events.filter((e:any)=>e.seq<marker.seq),transaction=events.filter((e:any)=>e.seq>=marker.seq);
 const reason=(transaction.find((e:any)=>e.type==='run.interrupted')!.payload as any).reason;
 assert.ok(operationReconciliationCommitEvents(prior,transaction,marker,reason));
 assert.equal(operationReconciliationCommitEvents(prior.filter((e:any)=>e.type!=='workspace.patch.prepared'),transaction,marker,reason),undefined);
 assert.equal(operationReconciliationCommitEvents(prior,transaction,marker,'patch_postcondition_reconciled'),undefined);
 const foreign={...transaction[0],id:'foreign',runId:'foreign-run',threadId:'foreign-thread'};
 assert.ok(operationReconciliationCommitEvents(prior,[...transaction,foreign],marker,reason));
 checked.push('actual mixed recovery journal scope accepts complete transaction; removing settled preparation or wrong terminal route fails; foreign-thread sequence collision stays scoped out');
 const retained=await reconcileSettledWorkspaceOperations(store.workspaceRoot,store.dataRoot,events);
 try{
  assert.equal(retained.patches.length,1);assert.equal(retained.moves.length,1);
  for(const relative of ['patched.txt','source-b/source.txt','target-b/moved.txt'])
   await assert.rejects(acquireWorkspacePathLocks(store.dataRoot,[path.join(store.workspaceRoot,relative)],'review contender'),/already being edited/);
  await retained.recheck();const file=path.join(store.workspaceRoot,'patched.txt');const originalBytes=await readFile(file);
  await writeFile(file,'noncooperative drift\n');await assert.rejects(retained.recheck(),/patch_postcondition_or_file_identity_changed/);await writeFile(file,originalBytes);
 }finally{await retained.release();}
 const all=await acquireWorkspacePathLocks(store.dataRoot,['patched.txt','source-b/source.txt','target-b/moved.txt'].map(p=>path.join(store.workspaceRoot,p)),'review after release');await all.release();
 checked.push('mixed settled patch and moved source/destination stay under one lease until release; recheck catches direct external patch drift');
 const checks=['patched.txt','target-b/moved.txt'].map((relative,index)=>({paths:[path.join(store.workspaceRoot,relative)],filePath:path.join(store.workspaceRoot,relative),maxBytes:1024,mismatchReason:'operation_review_mismatch',inspect:async()=>index===0}));
 await assert.rejects(lockWorkspaceOperationChecks(store.dataRoot,checks,'review fail cleanup'),/operation_review_mismatch/);
 const afterFailure=await acquireWorkspacePathLocks(store.dataRoot,checks.flatMap(c=>c.paths),'review failure released');await afterFailure.release();
 checked.push('a late failed participant releases every acquired path without partial retained lease');
 await writeFile(path.join(out,'result.json'),JSON.stringify({ok:true,fixture:'real native mixed patch/move; last operation crashed after effect',checks:checked,renames:await readFile(path.join(root,'renames.log'),'utf8'),sourceRunStatus:source.status,externalModelCalls:0,scope:'four grouped independent probes, not a wholesale rerun of owner133'},null,2)+'\n');
 console.log(JSON.stringify({ok:true,checks:checked.length}));
}finally{store.close();}
