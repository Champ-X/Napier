from pathlib import Path
import hashlib,json,tarfile,io
repo=Path('/Users/champ/orca/Napier');art=repo/'docs/artifacts';snapshot=Path('/private/tmp/napier-g04-batch-verify-20261030')
archive=art/'workspace-operation-batch-recovery-2026-10-30.tar.gz';files={}
def add(path,name):
 if path.is_file() and not path.is_symlink():files[name]=path
for category,root in [('before',Path('/tmp/napier-g04-operation-batch-before-20261030')),('after',Path('/tmp/napier-g04-operation-batch-after-20261030'))]:
 for p in root.rglob('*'):add(p,category+'/'+str(p.relative_to(root)))
for p in Path('/tmp').glob('napier-g04-*'):
 if p.is_file() and p.suffix in ['.log','.json']:
  add(p,'verification/'+p.name)
 elif p.is_dir() and p.name.startswith('napier-g04-batch-dev-'):
  for child in p.rglob('*'):add(child,'development/'+p.name+'/'+str(child.relative_to(p)))
owned=json.loads(Path('/tmp/napier-g04-batch-owned-source-v2-20261030.json').read_text())
for p in owned:add(snapshot/p,'frozen/'+p)
add(art/'workspace-operation-batch-recovery-regression-2026-10-30.json','verification/regression-receipt.json')
add(Path(__file__),'verification/'+Path(__file__).name)
index={}
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mtime=0;entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw));index[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'origin':str(p)}
raw=archive.read_bytes();result={'kind':'napier.g04-operation-batch-evidence-index','schemaVersion':1,'baseCommit':'e10a7bd39b71dc74dfb4bbd05f6c5254bedd5696','archive':{'name':archive.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'memberCount':len(index),'members':index}
(art/'workspace-operation-batch-recovery-evidence-index-2026-10-30.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'members':len(index),'bytes':len(raw),'sha256':result['archive']['sha256']}))
