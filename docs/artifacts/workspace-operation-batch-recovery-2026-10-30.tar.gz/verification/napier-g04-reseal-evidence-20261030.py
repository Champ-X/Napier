from pathlib import Path
import hashlib,io,json,subprocess,tarfile
repo=Path('/Users/champ/orca/Napier');art=repo/'docs/artifacts';archive=art/'workspace-operation-batch-recovery-2026-10-30.tar.gz';idx=art/'workspace-operation-batch-recovery-evidence-index-2026-10-30.json'
old_index=idx.read_bytes();old=json.loads(old_index);raw_archive=archive.read_bytes();assert hashlib.sha256(raw_archive).hexdigest()==old['archive']['sha256']
contents={};origins={}
with tarfile.open(fileobj=io.BytesIO(raw_archive),mode='r:gz') as tar:
 for member in tar:
  assert member.isfile();data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==old['members'][member.name]['sha256'];contents[member.name]=data;origins[member.name]=old['members'][member.name]['origin']
def add_bytes(name,data,origin):contents[name]=data;origins[name]=origin
def add(path,name):
 assert path.is_file() and not path.is_symlink(),path
 add_bytes(name,path.read_bytes(),str(path))
add_bytes('history/evidence-index-original.json',old_index,str(idx)+' (before supplemental reseal)')
add_bytes('history/regression-receipt-original.json',contents['verification/regression-receipt.json'],'original archive verification/regression-receipt.json')
add(Path('/tmp/napier-g04-delivery-manifest-20261030.json'),'history/delivery-manifest-original.json')
for prefix,root in [('independent-review',Path('/tmp/napier-g04-independent-review-20261030')),('integration/results',Path('/tmp/napier-g03-g04-integration-result-20261030'))]:
 for path in sorted(root.rglob('*')):
  if path.is_file() and not path.is_symlink():add(path,prefix+'/'+str(path.relative_to(root)))
for name in ['napier-g03-g04-integration-source-20261030.json','napier-g03-g04-integration-setup-20261030.py','napier-g03-g04-integration-verify-20261030.py','napier-g03-g04-source-commit-20261030.py','napier-g03-g04-source-commits-20261030.json']:
 add(Path('/tmp')/name,'integration/'+name)
owned=json.loads(contents['verification/napier-g04-batch-owned-source-v2-20261030.json'])
commit='bf6a34cdeede8e95e7932339de736f209954ecc5'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
commit_body=git('cat-file','commit',commit);add_bytes('integration/git-proof/commit',commit_body,'git commit '+commit)
root_tree=commit_body.splitlines()[0].decode().split()[1];trees={}
def tree(tree_id):
 if tree_id not in trees:
  raw=git('cat-file','tree',tree_id);add_bytes('integration/git-proof/trees/'+tree_id,raw,'git tree '+tree_id);entries={};offset=0
  while offset<len(raw):
   space=raw.index(b' ',offset);nul=raw.index(b'\0',space);name=raw[space+1:nul].decode();entries[name]=(raw[offset:space].decode(),raw[nul+1:nul+21].hex());offset=nul+21
  trees[tree_id]=entries
 return trees[tree_id]
for path,sha in owned.items():
 assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==sha
 current=root_tree;parts=path.split('/')
 for part in parts[:-1]: mode,current=tree(current)[part];assert mode=='40000'
 mode,blob=tree(current)[parts[-1]];body=contents['frozen/'+path];assert hashlib.sha1(f'blob {len(body)}\0'.encode()+body).hexdigest()==blob
add(art/'workspace-operation-batch-recovery-regression-2026-10-30.json','verification/regression-receipt.json')
add(Path(__file__),'verification/'+Path(__file__).name)
new_index={};temporary=archive.with_suffix('.tmp')
with tarfile.open(temporary,'w:gz',compresslevel=9) as tar:
 for name,data in sorted(contents.items()):
  entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0;entry.mode=0o644;tar.addfile(entry,io.BytesIO(data));new_index[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'origin':origins[name]}
raw=temporary.read_bytes();result={'kind':old['kind'],'schemaVersion':old['schemaVersion'],'baseCommit':old['baseCommit'],'sourceCommit':commit,'archive':{'name':archive.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'memberCount':len(new_index),'members':new_index,'companionArtifacts':[],'supplementalEvidence':{'independentGroupedProbes':4,'integrationFocusedCases':75,'originalUniqueCases':133,'addedToOriginalUniqueCases':0}}
for name in ['workspace-operation-batch-recovery-regression-2026-10-30.json','workspace-operation-batch-recovery-reconcile-2026-10-30.py']:
 raw_comp=(art/name).read_bytes();result['companionArtifacts'].append({'name':name,'bytes':len(raw_comp),'sha256':hashlib.sha256(raw_comp).hexdigest()})
temporary.replace(archive);idx.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'members':len(new_index),'bytes':result['archive']['bytes'],'sha256':result['archive']['sha256']}))
