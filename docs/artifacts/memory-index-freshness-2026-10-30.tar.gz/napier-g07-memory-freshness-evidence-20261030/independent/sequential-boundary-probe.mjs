import { TaskMemoryDependencySnapshot } from '/tmp/napier-g07-memory-freshness-20261030/packages/runtime/dist/task-memory-dependencies.js';
const files = new Map([['a.ts', 'hashA'], ['b.ts', 'hashB']]);
let reads = 0;
const snapshot = new TaskMemoryDependencySnapshot(async (name) => {
  reads++;
  const result = files.get(name);
  if (reads === 4) files.set('a.ts', 'newHashA');
  return result;
});
const a = { source: { fileDependencies: [{ path: 'a.ts', sha256: 'hashA' }] } };
const b = { source: { fileDependencies: [{ path: 'b.ts', sha256: 'hashB' }] } };
await snapshot.accepts(a);
await snapshot.accepts(b);
await snapshot.revalidate();
console.log(JSON.stringify({
  boundary: 'Sequential post-index checks are not an atomic multi-file snapshot',
  mechanism: 'Synthetic digest reader changes a.ts after its recheck while b.ts is rechecked',
  aObservedHash: 'hashA', aCurrentHash: files.get('a.ts'),
  aRetained: snapshot.retains(a), bRetained: snapshot.retains(b), receipt: snapshot.receipt(),
}, null, 2));
