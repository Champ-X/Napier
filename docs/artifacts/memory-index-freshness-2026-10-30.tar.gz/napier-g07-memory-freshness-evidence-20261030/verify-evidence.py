#!/usr/bin/env python3
"""Read-only integrity verification. Never imports or executes archived tests/probes."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkout', type=Path, help='Optional checkout containing the four committed source files')
args = parser.parse_args()
root = Path(__file__).resolve().parent

def read(name):
    return json.loads((root / name).read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = read('manifest.json')
for artifact in manifest['artifacts']:
    relative = Path(artifact['path'])
    path = root / relative
    if relative.is_absolute() or '..' in relative.parts or not path.resolve().is_relative_to(root):
        raise SystemExit(f'Artifact path escapes bundle: {relative}')
    if not path.is_file() or path.stat().st_size != artifact['bytes'] or digest(path) != artifact['sha256']:
        raise SystemExit(f'Artifact mismatch: {relative}')
receipt = read('root-source-commit.json')
assert receipt['commit'] == 'c4c7c75c5c55248fc5b3abc6105dff0b6b55cab7'
for name, expected in receipt['sourceManifest']['files'].items():
    assert digest(root / 'source' / name) == expected, name
    if args.checkout:
        assert digest(args.checkout / name) == expected, name
review = read('independent/review.json')
assert {item['path']: item['sha256'] for item in review['files']} == receipt['sourceManifest']['files']
assert read('integrated/source-manifest.json')['files'] == receipt['sourceManifest']['files']

specs = {'before': ('before/tests.json', 1, 0, 2),
         'initial36': ('initial-after/tests.json', 3, 36, 0),
         'final73': ('final-isolated/tests.json', 8, 73, 0),
         'integrated23': ('integrated/tests.json', 4, 23, 0),
         'independent68': ('independent/tests.json', 8, 68, 0)}
identity_record = read('case-identity-overlap.json')
identities = {}
for label, (file, count_files, passed, failed) in specs.items():
    report = read(file)
    assert len(report['testResults']) == count_files
    assert report['numPassedTests'] == passed and report['numFailedTests'] == failed
    assert report['success'] == (failed == 0)
    rows = []
    for suite in report['testResults']:
        for case in suite['assertionResults']:
            rows.append({'file': 'packages/runtime/test/' + Path(suite['name']).name,
                         'ancestorTitles': case['ancestorTitles'], 'title': case['title'],
                         'fullName': case['fullName'], 'status': case['status']})
    assert len(rows) == passed + failed
    assert sum(row['status'] == 'passed' for row in rows) == passed
    assert sum(row['status'] == 'failed' for row in rows) == failed
    assert rows == identity_record['records'][label]
    identities[label] = Counter((row['file'], tuple(row['ancestorTitles']), row['title'], row['fullName']) for row in rows)
assert len(identities['final73']) == 55 and len(identities['independent68']) == 50
for label, expected in {'initial36': 35, 'integrated23': 11, 'independent68': 66}.items():
    assert sum((identities[label] & identities['final73']).values()) == expected
probe = read('independent/sequential-boundary-result.json')
assert probe['aObservedHash'] != probe['aCurrentHash'] and probe['aRetained'] and probe['bRetained']
assert probe['receipt']['readCount'] == 4
print(json.dumps({'artifactHashesVerified': len(manifest['artifacts']),
                  'sourceCommit': receipt['commit'], 'testRecordCounts': {'beforeFailed': 2, 'initial': 36, 'final': 73, 'integrated': 23, 'independent': 68},
                  'overlapWithFinalRecords': {'initial': 35, 'integrated': 11, 'independent': 66},
                  'countsAreNotAdditive': True, 'archivedCodeExecuted': False,
                  'checkoutVerified': str(args.checkout) if args.checkout else None}, indent=2))
